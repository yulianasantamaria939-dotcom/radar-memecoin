# Radar Memecoin IA PRO

Radar de **detección temprana multicadena** de memecoins. Descubre pares nuevos, los analiza (mercado + contrato),
asigna una **puntuación de oportunidad** y otra de **riesgo** (independientes), calcula escenarios de entrada,
invalidación y salida, y avisa por Telegram. **Solo analiza: no compra ni vende nada, jamás.**

> No es consejo financiero. Ninguna puntuación garantiza ganancias ni detecta todas las estafas.
> Una moneda sin alertas **no** es una moneda segura. Puedes perder todo lo que inviertas.

## Instalación

Solo necesitas **Python 3.9 o superior** (probado en 3.13). No hay que instalar paquetes.

```bash
cd radar-memecoin-ia-pro
cp .env.example .env        # opcional: Telegram, FOMO, etc.
python3 run.py              # abre http://127.0.0.1:8000
```

En Windows usa `python run.py` y copia `.env.example` a `.env` con el Explorador.
`python3 run.py --once` hace un solo ciclo y muestra el estado de cada fuente en consola (útil para diagnosticar).

## Qué fuentes usa

| Fuente | Para qué | Clave |
|---|---|---|
| **DexScreener** | Perfiles/boosts nuevos, métricas de pares de todas las redes | No |
| **GeckoTerminal** | Pools nuevos por red y en tendencia, compradores/vendedores únicos | No |
| **GoPlus** | Seguridad del contrato (honeypot, impuestos, mint, propietarios, liquidez bloqueada) en EVM y Solana | Opcional (más cupo) |
| **Solana RPC** | Respaldo: autoridades de creación/congelación del mint | No |
| **FOMO** (vía fomoapi.io) | Monedas en los tableros de la app FOMO (tendencia, graduadas) | **Sí, gratuita** |
| **Telegram** | Alertas | Bot token + chat id |

### Sobre FOMO (importante)
La app FOMO **no tiene API pública oficial**. La única vía que encontré es **fomoapi.io**, un servicio de **terceros
no afiliado a FOMO**. Su plan gratis (≈1.000 consultas/mes) exige clave: ponla en `FOMOAPI_KEY`.
Por eso el radar la consulta cada 3 h por defecto (`RADAR_FOMO_INTERVAL_SECONDS`). Las monedas que aparecen allí se
marcan con la etiqueta **FOMO** y tienen su propia pestaña. Eso refleja *popularidad entre usuarios de FOMO*, no calidad,
y **no es el catálogo completo de FOMO**. Sin clave, esa fuente aparece como «sin configurar» y no se simula nada.
Bitquery también expone operaciones de FOMO en Solana, pero requiere clave y no está integrada.

## Redes
Solana, Ethereum, Base, BNB Chain, Arbitrum, Polygon, Avalanche, Optimism, Sui y TON (editable en `RADAR_NETWORKS`).
Si DexScreener o FOMO devuelven una red que no está en el catálogo, **la moneda se conserva igualmente**.
Análisis de contrato (GoPlus): EVM y Solana. En Sui/TON y otras redes el contrato figura como «no analizado» (riesgo desconocido).

## Cómo decide
- **Oportunidad (0–100)**: antigüedad, liquidez, aceleración del volumen, compras vs ventas, tendencia, participación.
- **Riesgo (0–100)**: alertas del contrato, impuestos, concentración, liquidez baja/en caída, patrones de manipulación, +10 de riesgo inherente a toda memecoin.
- Cada alerta se etiqueta **confirmado** (lo reporta el analizador o se midió), **sospecha** o **desconocido**. Un dato ausente nunca se toma como seguro y baja la **confianza**.
- **Clasificación**: oportunidad temprana · en observación · alto riesgo · posible estafa.
- **Señal**: ENTRADA POTENCIAL · ESPERAR · NO ENTRAR · POSIBLE SALIDA · FOMO ALTO. Sin análisis de contrato nunca hay «entrada potencial».
- **Niveles** (zona, invalidación, objetivos, relación riesgo/beneficio): reglas fijas sobre el precio actual, no predicciones.
- **Nada se oculta**: pestañas y filtros solo cambian la vista; «Ver TODAS» muestra todo lo detectado.

## Alertas y Telegram
1. Crea un bot con @BotFather → pon `TELEGRAM_BOT_TOKEN`; obtén tu chat id → `TELEGRAM_CHAT_ID` en `.env`.
2. Reinicia, abre «Alertas y Telegram», elige tipos/umbrales y pulsa «Enviar mensaje de prueba».
Sin duplicados (enfriamiento por moneda y tipo), con tope por ciclo y filtro de antigüedad para «nueva moneda».
Las alertas se guardan siempre en la pestaña **Alertas**, aunque Telegram no esté configurado.

## Seguridad
- Claves y token de Telegram **solo en `.env` del servidor**; ninguna respuesta de la API los incluye (hay pruebas).
- El servidor escucha en `127.0.0.1` por defecto. Cambiar ajustes solo se permite desde el propio equipo, o con `RADAR_ADMIN_TOKEN` si lo expones.
- Todo texto externo (nombres de monedas) se muestra como texto, nunca como HTML.
- No se piden claves privadas ni frases semilla.

## Estado real de cada función

Probado con `python3 -m pytest tests` (**40 pruebas**, todas pasan) y en un navegador real (Chromium) contra un servidor local.

| Función | Estado |
|---|---|
| Normalización, deduplicación entre fuentes, redes desconocidas | ✅ Probado (datos de ejemplo con el formato documentado) |
| Puntuaciones, clasificación, señales, niveles, textos explicativos | ✅ Probado |
| Límites de frecuencia, reintentos, errores por fuente, corte si una fuente cae | ✅ Probado |
| Alertas sin duplicados, umbrales, tope por ciclo, HTML escapado | ✅ Probado |
| Interfaz: tabla, búsqueda, filtros, pestañas, ficha, gráficos, móvil, anti-XSS | ✅ Probado en navegador |
| Claves no expuestas en ninguna respuesta | ✅ Probado |
| **Conexión real a DexScreener / GeckoTerminal / GoPlus** | ⚠️ **No verificada**: mi entorno bloquea esos dominios. Las pruebas usan respuestas simuladas solo dentro de `tests/`. Al ejecutarlo en tu equipo, el panel mostrará «conectada» o el error exacto de cada fuente |
| Lectura de GoPlus para **Solana** y tableros de **fomoapi.io** | ⚠️ Implementado según su documentación pública; el formato real puede diferir (campos ausentes quedan como «no disponible») |
| Envío real a Telegram | ⚠️ No verificado con un bot real (probado con transporte simulado) |
| FOMO: catálogo completo de la app | ❌ No es posible: no hay API oficial; solo tableros vía fomoapi.io con clave |
| Bloqueo de liquidez en Solana, wallets vinculadas/coordinadas, volumen artificial on-chain | ❌ Pendiente: requiere análisis on-chain o APIs de pago; hoy se usan solo heurísticas de mercado y datos de GoPlus |
| Precio de pago / cuotas | GeckoTerminal ≈30 consultas/min gratis; DexScreener 60–300/min; fomoapi.io ≈20/min y ≈1.000/mes gratis |

## Estructura
```
run.py              arranque
radar/              chains · sources · normalize · security · scoring · alerts · collector · db · server · telegram · http · config
static/             interfaz (index.html, app.js, style.css)
tests/              pruebas (los datos simulados viven solo aquí)
data/radar.db       base de datos SQLite (se crea sola)
```
