"use strict";
/* Radar Memecoin IA PRO — interfaz. Todo el texto externo (nombres, símbolos...) se inserta con
   textContent: nunca como HTML. Las claves no llegan al navegador. */

const $ = (id) => document.getElementById(id);
const state = { tokens: [], status: null, tab: "todas", sort: { key: "first_seen", dir: -1 }, page: 0, pageSize: 100,
  nowOffset: 0, openKey: null, alerts: [] };

function el(tag, attrs, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "class") n.className = v;
    else if (k === "onclick") n.addEventListener("click", v);
    else if (k === "href") { if (/^https?:\/\//i.test(v)) { n.href = v; n.target = "_blank"; n.rel = "noopener noreferrer"; } }
    else n.setAttribute(k, v);
  }
  for (const k of kids.flat()) if (k !== null && k !== undefined && k !== false) n.append(k.nodeType ? k : document.createTextNode(String(k)));
  return n;
}
const na = () => el("span", { class: "na" }, "n/d");

/* ---------- formato ---------- */
const usd = (v) => v == null ? "n/d" : v >= 1e9 ? "$" + (v / 1e9).toFixed(2) + "B" : v >= 1e6 ? "$" + (v / 1e6).toFixed(2) + "M" : v >= 1e3 ? "$" + (v / 1e3).toFixed(1) + "K" : "$" + v.toFixed(2);
const price = (p) => p == null ? "n/d" : p >= 1 ? "$" + p.toFixed(4) : p >= 0.0001 ? "$" + p.toFixed(6) : "$" + p.toPrecision(3);
const age = (m) => m == null ? "n/d" : m < 60 ? Math.floor(m) + " min" : m < 2880 ? (m / 60).toFixed(1) + " h" : (m / 1440).toFixed(1) + " d";
const ago = (ms) => { if (!ms) return "nunca"; const s = Math.max(0, Math.round((Date.now() + state.nowOffset - ms) / 1000)); return s < 60 ? s + " s" : s < 3600 ? Math.floor(s / 60) + " min" : Math.floor(s / 3600) + " h"; };
const hhmmss = (ms) => ms ? new Date(ms).toLocaleTimeString("es") : "—";
const short = (a) => a && a.length > 14 ? a.slice(0, 6) + "…" + a.slice(-4) : a;
function pct(v) { return v == null ? na() : el("span", { class: v >= 0 ? "pos" : "neg" }, (v >= 0 ? "+" : "") + v.toFixed(1) + "%"); }
function meter(v, cls) { return el("span", { class: "meter " + cls }, el("b", {}, v == null ? "—" : v), el("span", { class: "bar" }, el("i", { style: `width:${v || 0}%` }))); }
const sigClass = (s) => "badge s-" + (s || "").split(" ")[0];
const ageNow = (t) => t.age_min == null ? null : t.age_min + (Date.now() + state.nowOffset - state.fetchedAt) / 60000;

async function api(path, opts) {
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || "HTTP " + r.status); e.status = r.status; throw e; }
  return j;
}

/* ---------- carga ---------- */
async function loadTokens() {
  const j = await api("/api/tokens");
  state.tokens = j.tokens; state.fetchedAt = Date.now(); state.nowOffset = j.now - Date.now();
  state.updatedAt = j.updated_at;
  fillChains();
}
async function loadStatus() { state.status = await api("/api/status"); }
async function refresh() {
  try {
    await Promise.all([loadTokens(), loadStatus()]);
    state.offline = false;
  } catch (e) { state.offline = true; }
  render();
  if (state.tab === "alertas") loadAlerts();
}

/* ---------- filtros ---------- */
const F = () => ({ q: $("q").value.trim().toLowerCase(), chain: $("fChain").value, cls: $("fClass").value, sig: $("fSignal").value,
  age: parseFloat($("fAge").value), liq: parseFloat($("fLiq").value), vol: parseFloat($("fVol").value),
  opp: parseFloat($("fOpp").value), risk: parseFloat($("fRisk").value) });
const filtersActive = () => { const f = F(); return !!(f.q || f.chain || f.cls || f.sig || [f.age, f.liq, f.vol, f.opp, f.risk].some((x) => !isNaN(x))); };
function fillChains() {
  const sel = $("fChain"), cur = sel.value, seen = new Map();
  state.tokens.forEach((t) => seen.set(t.chain, t.chain_name));
  const have = new Set([...sel.options].map((o) => o.value));
  [...seen].sort((a, b) => a[1].localeCompare(b[1])).forEach(([k, v]) => { if (!have.has(k)) sel.append(el("option", { value: k }, v)); });
  sel.value = cur;
}
const TABS = [
  ["todas", "Todas", () => true],
  ["nuevas", "Nuevas (24 h)", (t) => t.age_min != null && ageNow(t) <= 1440],
  ["oportunidades", "Oportunidades potenciales", (t) => t.classification === "oportunidad_temprana"],
  ["parabolica", "Subida parabólica (FOMO)", (t) => t.stage === "fomo"],
  ["riesgo", "Alto riesgo / estafa", (t) => t.classification === "alto_riesgo" || t.classification === "posible_estafa"],
  ["appfomo", "Desde la app FOMO", (t) => t.is_fomo],
  ["alertas", "Alertas", null],
];
function visible() {
  const f = F(), tab = TABS.find((x) => x[0] === state.tab);
  let rows = state.tokens.filter(tab[2] || (() => true));
  rows = rows.filter((t) => {
    if (f.q && !(`${t.name} ${t.symbol} ${t.chain_name} ${t.chain} ${t.address}`.toLowerCase().includes(f.q))) return false;
    if (f.chain && t.chain !== f.chain) return false;
    if (f.cls && t.classification !== f.cls) return false;
    if (f.sig && t.signal !== f.sig) return false;
    if (!isNaN(f.age) && (t.age_min == null || ageNow(t) > f.age * 60)) return false;
    if (!isNaN(f.liq) && (t.liquidity == null || t.liquidity < f.liq)) return false;
    if (!isNaN(f.vol) && (t.volume24 == null || t.volume24 < f.vol)) return false;
    if (!isNaN(f.opp) && (t.opp == null || t.opp < f.opp)) return false;
    if (!isNaN(f.risk) && (t.risk == null || t.risk > f.risk)) return false;
    return true;
  });
  const { key, dir } = state.sort;
  const val = (t) => key === "age_min" ? t.age_min : key.startsWith("pc.") ? t.pc[key.slice(3)] : t[key];
  rows.sort((a, b) => { const x = val(a), y = val(b); if (x == null && y == null) return 0; if (x == null) return 1; if (y == null) return -1;
    return (typeof x === "string" ? x.localeCompare(y) : x - y) * dir; });
  return rows;
}

/* ---------- render ---------- */
const COLS = [
  ["name", "Moneda"], ["chain_name", "Red"], ["address", "Contrato"], ["age_min", "Edad"], ["price", "Precio"],
  ["liquidity", "Liquidez"], ["market_cap", "Cap."], ["volume24", "Vol 24h"], ["pc.m5", "5m"], ["pc.h1", "1h"],
  ["pc.h6", "6h"], ["pc.h24", "24h"], ["opp", "Oportunidad"], ["risk", "Riesgo"], ["signal", "Señal"],
  ["classification", "Clasificación"], ["alerts", "Alertas"], ["reason", "Motivo"],
];
function render() {
  renderHeader(); renderSources(); renderCards(); renderTabs();
  const isAlerts = state.tab === "alertas";
  $("tbl").parentElement.hidden = isAlerts; $("alertsView").hidden = !isAlerts; $("pager").hidden = isAlerts;
  $("filters").hidden = isAlerts; $("countInfo").hidden = isAlerts;
  if (!isAlerts) renderTable();
}
function renderHeader() {
  const s = state.status, upd = state.updatedAt || (s && s.cycle.last_finished);
  const dot = $("dot");
  if (state.offline) { dot.className = "dot err"; $("updated").textContent = "Sin conexión con el servidor del radar"; return; }
  const errs = s ? s.sources.filter((x) => x.state === "error").length : 0;
  dot.className = "dot " + (!upd ? "idle" : errs ? "err" : "ok");
  $("updated").textContent = upd ? `Última actualización: ${hhmmss(upd)} (hace ${ago(upd)})` + (s && s.cycle.running ? " · actualizando…" : "")
    : "Esperando el primer ciclo de datos…";
  const box = $("errors"), msgs = [];
  if (s) {
    s.sources.filter((x) => x.state === "error").forEach((x) => msgs.push(`${x.label}: ${x.last_error}`));
    (s.cycle.errors || []).slice(0, 4).forEach((e) => msgs.push(e));
  }
  box.hidden = !msgs.length;
  box.replaceChildren(el("b", {}, "Problemas de conexión: "), [...new Set(msgs)].join(" · "));
}
function renderSources() {
  const s = state.status; if (!s) return;
  const color = { ok: "var(--good)", error: "var(--bad)", idle: "var(--muted)", sin_configurar: "var(--warn)" };
  const txt = { ok: "conectada", error: "con error", idle: "sin consultar aún", sin_configurar: "sin configurar" };
  $("sources").replaceChildren(...s.sources.map((x) => el("span", { class: "chip", title: x.note || x.last_error || "" },
    el("i", { style: `width:8px;height:8px;border-radius:50%;background:${color[x.state]};display:inline-block` }),
    x.label, el("small", {}, txt[x.state] + (x.latency_ms && x.state === "ok" ? ` · ${x.latency_ms} ms` : "")))));
}
function renderCards() {
  const t = state.tokens, n = (f) => t.filter(f).length;
  const items = [["Monedas detectadas", t.length], ["Nuevas (24 h)", n((x) => x.age_min != null && ageNow(x) <= 1440)],
    ["Oportunidades potenciales", n((x) => x.classification === "oportunidad_temprana")],
    ["Subida parabólica", n((x) => x.stage === "fomo")], ["Alto riesgo / estafa", n((x) => x.classification === "alto_riesgo" || x.classification === "posible_estafa")],
    ["Desde app FOMO", n((x) => x.is_fomo)]];
  $("cards").replaceChildren(...items.map(([l, v]) => el("div", { class: "card" }, el("b", {}, v), el("span", {}, l))));
}
function renderTabs() {
  $("tabs").replaceChildren(...TABS.map(([k, label, fn]) => el("button", { class: "tab", role: "tab", "aria-selected": state.tab === k,
    onclick: () => { state.tab = k; state.page = 0; render(); if (k === "alertas") loadAlerts(); } },
    label, fn ? el("i", {}, state.tokens.filter(fn).length) : null)));
}
function renderTable() {
  $("thead").replaceChildren(...COLS.map(([k, label]) => el("th", { class: state.sort.key === k ? "sorted" : "",
    onclick: () => { state.sort = { key: k, dir: state.sort.key === k ? -state.sort.dir : -1 }; render(); } },
    label + (state.sort.key === k ? (state.sort.dir > 0 ? " ▲" : " ▼") : ""))));
  const rows = visible(), total = state.tokens.length, pages = Math.max(1, Math.ceil(rows.length / state.pageSize));
  state.page = Math.min(state.page, pages - 1);
  const slice = rows.slice(state.page * state.pageSize, (state.page + 1) * state.pageSize);
  const hidden = state.tokens.length - rows.length;
  $("countInfo").textContent = `Mostrando ${slice.length ? state.page * state.pageSize + 1 : 0}–${state.page * state.pageSize + slice.length} de ${rows.length} monedas` +
    (hidden > 0 ? ` · ${hidden} de las ${total} detectadas no se muestran por la pestaña o filtros activos (pulsa «Ver TODAS»).` : ` (todas las detectadas).`);
  $("tbody").replaceChildren(...(slice.length ? slice.map(row) : [el("tr", {}, el("td", { colspan: COLS.length, class: "muted" },
    total ? "Ninguna moneda coincide con estos filtros." : state.status && state.status.cycle.cycles ? "Aún no se ha detectado ninguna moneda. Revisa el estado de las fuentes arriba." : "Esperando el primer ciclo de datos…"))]));
  $("pager").replaceChildren(
    el("button", { class: "btn ghost", onclick: () => { state.page = Math.max(0, state.page - 1); renderTable(); } }, "← Anterior"),
    el("span", { class: "muted" }, `Página ${state.page + 1} de ${pages}`),
    el("button", { class: "btn ghost", onclick: () => { state.page = Math.min(pages - 1, state.page + 1); renderTable(); } }, "Siguiente →"));
}
function row(t) {
  const copy = el("button", { class: "copy", title: "Copiar contrato", onclick: (e) => { e.stopPropagation(); navigator.clipboard && navigator.clipboard.writeText(t.address); e.target.textContent = "¡copiado!"; setTimeout(() => (e.target.textContent = "copiar"), 1200); } }, "copiar");
  const tr = el("tr", { tabindex: 0, onclick: () => openDrawer(t.key) },
    el("td", { class: "name" }, el("b", {}, t.name || "(sin nombre)"), el("small", {}, t.symbol || "?"), " ", t.is_fomo ? el("span", { class: "tag fomo" }, "FOMO") : null),
    el("td", {}, t.chain_name), el("td", {}, el("span", { class: "addr" }, short(t.address)), copy),
    el("td", { class: "num" }, age(ageNow(t))), el("td", { class: "num" }, price(t.price)), el("td", { class: "num" }, usd(t.liquidity)),
    el("td", { class: "num" }, usd(t.market_cap)), el("td", { class: "num" }, usd(t.volume24)),
    ...["m5", "h1", "h6", "h24"].map((w) => el("td", { class: "num" }, pct(t.pc[w]))),
    el("td", {}, meter(t.opp, "o")), el("td", {}, meter(t.risk, "r")),
    el("td", {}, el("span", { class: sigClass(t.signal) }, t.signal)),
    el("td", {}, el("span", { class: "badge b-" + t.classification }, t.classification_label)),
    el("td", {}, t.alerts.length ? t.alerts.map((a) => el("span", { class: "tag alert" }, a.replace(/_/g, " "))) : el("span", { class: "na" }, "—")),
    el("td", { class: "reason", title: t.reason }, t.reason || ""));
  tr.addEventListener("keydown", (e) => { if (e.key === "Enter") openDrawer(t.key); });
  return tr;
}

/* ---------- alertas ---------- */
async function loadAlerts() {
  try { state.alerts = (await api("/api/alerts?limit=200")).alerts; } catch (e) { state.alerts = []; }
  const box = $("alertsView");
  if (!state.alerts.length) { box.replaceChildren(el("p", { class: "muted", style: "padding:14px" }, "Todavía no hay alertas registradas.")); return; }
  box.replaceChildren(...state.alerts.map((a) => el("div", { class: "alertitem", onclick: () => openDrawer(a.key) },
    el("div", { class: "muted" }, new Date(a.ts).toLocaleString("es")),
    el("div", {}, el("b", {}, a.title), " · ", `${a.name || "?"} (${a.symbol || "?"})`, el("div", { class: "muted" }, a.message),
      el("small", { class: "muted" }, "Telegram: " + a.telegram)))));
}

/* ---------- detalle ---------- */
function svgLine(points, color) {
  const ns = "http://www.w3.org/2000/svg", svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 300 100"); svg.setAttribute("class", "chart"); svg.setAttribute("preserveAspectRatio", "none");
  const pts = points.filter((p) => p[1] != null);
  if (pts.length < 2) { return null; }
  const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const sx = (x) => 6 + ((x - x0) / (x1 - x0 || 1)) * 288, sy = (y) => 94 - ((y - y0) / (y1 - y0 || 1)) * 88;
  const pl = document.createElementNS(ns, "polyline");
  pl.setAttribute("points", pts.map((p) => sx(p[0]).toFixed(1) + "," + sy(p[1]).toFixed(1)).join(" "));
  pl.setAttribute("fill", "none"); pl.setAttribute("stroke", color); pl.setAttribute("stroke-width", "2"); pl.setAttribute("vector-effect", "non-scaling-stroke");
  svg.append(pl); return svg;
}
function chartBox(title, points, color, fmt) {
  const svg = svgLine(points, color), ys = points.filter((p) => p[1] != null).map((p) => p[1]);
  return el("div", {}, el("small", { class: "muted" }, title + (ys.length ? ` · mín ${fmt(Math.min(...ys))} · máx ${fmt(Math.max(...ys))}` : "")),
    svg || el("p", { class: "muted" }, "Aún no hay suficiente historial (se acumula con cada actualización)."));
}
const li = (arr, empty) => arr.length ? el("ul", {}, arr.map((x) => el("li", {}, x))) : el("p", { class: "muted" }, empty);

async function openDrawer(key) {
  state.openKey = key; $("drawer").hidden = false; $("drawerBody").replaceChildren(el("p", { class: "muted" }, "Cargando…"));
  let d;
  try { d = await api("/api/token/" + encodeURIComponent(key)); } catch (e) { $("drawerBody").replaceChildren(el("p", { class: "neg" }, "No se pudo cargar: " + e.message)); return; }
  if (state.openKey !== key) return;
  const r = d.row, a = d.analysis, t = d.token, lv = a.levels, m = a.metrics;
  const flagsBy = (lvl) => a.risk_flags.filter((f) => f.level === lvl);
  const flagList = (lvl, label) => flagsBy(lvl).length ? el("div", {}, el("p", {}, el("span", { class: "lvl " + lvl }, label)),
    el("ul", {}, flagsBy(lvl).map((f) => el("li", {}, f.text)))) : null;
  const body = [
    el("h2", {}, `${r.name || "(sin nombre)"} `, el("small", { class: "muted" }, r.symbol || "")),
    el("p", {}, el("span", { class: "badge b-" + r.classification }, r.classification_label), " ", el("span", { class: sigClass(r.signal) }, r.signal), " ",
      el("span", { class: "tag" }, r.stage_label), r.is_fomo ? el("span", { class: "tag fomo" }, "App FOMO") : null),
    el("p", {}, `${r.chain_name} · contrato `, el("span", { class: "addr" }, r.address), " · ",
      r.dex_url ? el("a", { href: r.dex_url }, "DexScreener") : null, r.dex_url && r.explorer_url ? " · " : null,
      r.explorer_url ? el("a", { href: r.explorer_url }, "Explorador") : null),
    el("h3", {}, "¿Qué está pasando?"), el("div", { class: "box" }, a.summary),
    el("h3", {}, "¿Por qué se detectó?"), el("p", {}, a.why_detected),
    el("div", { class: "scores" },
      el("div", { class: "box" }, el("small", { class: "muted" }, "Oportunidad"), meter(a.opportunity, "o")),
      el("div", { class: "box" }, el("small", { class: "muted" }, "Riesgo"), meter(a.risk, "r")),
      el("div", { class: "box" }, el("small", { class: "muted" }, "Confianza del análisis"), el("b", {}, a.confidence + "%"), el("small", {}, a.confidence_label))),
    el("h3", {}, "Señal actual"), li(a.signal_reasons, "—"),
    el("h3", {}, "Señales buenas"), li(a.positives, "No hay señales claramente favorables."),
    el("h3", {}, "Señales peligrosas"), el("div", {}, flagList("confirmado", "Riesgo confirmado"), flagList("sospecha", "Sospecha"),
      flagList("desconocido", "Datos no disponibles (no se asume seguro)"), flagList("inherente", "Riesgo inherente"), !a.risk_flags.some((f) => f.level === "confirmado" || f.level === "sospecha") ? el("p", { class: "muted" }, "No se detectaron alertas específicas con los datos disponibles. Esto NO significa que sea segura.") : null),
    el("h3", {}, "¿Qué tendría que ocurrir para cambiar la clasificación?"), li(a.what_would_change, "—"),
    el("h3", {}, "Información que falta"), li(a.missing, "No faltan datos importantes."),
    el("h3", {}, "Entradas, invalidación y salidas"),
  ];
  if (lv) {
    body.push(el("div", { class: "box" },
      el("p", {}, el("b", {}, "Zona de entrada calculada: "), `${price(lv.entry_zone[0])} – ${price(lv.entry_zone[1])}`), el("p", { class: "muted" }, lv.entry_note),
      el("p", {}, el("b", {}, "Invalidación de la idea: "), `${price(lv.invalidation)} (si pierde este nivel, el escenario deja de ser válido)`),
      el("table", { class: "mini" }, el("tbody", {}, lv.targets.map((x) => el("tr", {}, el("td", {}, x.label), el("td", {}, price(x.price)), el("td", {}, "+" + x.gain_pct.toFixed(0) + "%"), el("td", {}, "R/B " + x.risk_reward))))),
      el("p", { class: "muted" }, lv.impact_100_usd_pct != null ? `Impacto de precio estimado: ≈${lv.impact_100_usd_pct}% con $100 y ≈${lv.impact_1000_usd_pct}% con $1.000 (según liquidez).` : ""),
      el("p", { class: "muted" }, lv.note)));
  } else {
    body.push(el("div", { class: "box" }, el("b", {}, "No hay suficientes evidencias para proponer una entrada. "),
      r.signal === "NO ENTRAR" ? "El riesgo es demasiado alto." : r.signal === "POSIBLE SALIDA" || r.signal === "FOMO ALTO" ? "El momento actual no favorece entrar." : "Faltan datos o confirmaciones (ver arriba)."));
  }
  if (a.exit_signals.length) body.push(el("p", {}, el("b", {}, "Señales de salida a vigilar:")), el("ul", {}, a.exit_signals.map((x) =>
    el("li", {}, x.text, x.active === true ? el("b", { class: "neg" }, " — ACTIVA AHORA") : x.active === false ? el("span", { class: "muted" }, " — no activa") : null))));
  body.push(el("h3", {}, "Cómo se calculó la oportunidad"),
    el("table", { class: "mini" }, el("tbody", {}, a.opportunity_factors.map((f) => el("tr", {}, el("td", {}, f.name), el("td", {}, `${f.points}/${f.max}`), el("td", { class: "muted" }, f.detail))))));
  const w = ["m5", "h1", "h6", "h24"];
  body.push(el("h3", {}, "Métricas"),
    el("div", { class: "kv" }, [["Precio", price(t.price_usd)], ["Liquidez", usd(t.liquidity_usd)], ["Capitalización", usd(t.market_cap || t.fdv)],
      ["Antigüedad", age(m.age_min)], ["Aceleración vol.", m.volume_accel == null ? "n/d" : m.volume_accel.toFixed(1) + "×"],
      ["% compras", m.buy_ratio == null ? "n/d" : (m.buy_ratio * 100).toFixed(0) + "%"]].map(([k, v]) => el("div", {}, el("small", {}, k), v))),
    el("table", { class: "mini" }, el("thead", {}, el("tr", {}, ["", "5m", "1h", "6h", "24h"].map((x) => el("th", {}, x)))),
      el("tbody", {}, el("tr", {}, el("td", {}, "Variación"), w.map((k) => el("td", {}, pct((t.price_change || {})[k])))),
        el("tr", {}, el("td", {}, "Volumen"), w.map((k) => el("td", {}, usd((t.volume || {})[k])))),
        el("tr", {}, el("td", {}, "Compras/Ventas"), w.map((k) => { const x = (t.txns || {})[k] || {}; return el("td", {}, x.buys == null ? "n/d" : `${x.buys}/${x.sells}`); })),
        el("tr", {}, el("td", {}, "Compr./Vend. únicos"), w.map((k) => { const x = (t.txns || {})[k] || {}; return el("td", {}, x.buyers == null ? "n/d" : `${x.buyers}/${x.sellers}`); })))));
  body.push(el("h3", {}, "Gráficos (historial desde que el radar la vigila)"),
    chartBox("Precio", d.history.map((h) => [h.ts, h.price]), "#4cc9f0", price),
    chartBox("Liquidez", d.history.map((h) => [h.ts, h.liq]), "#35d07f", usd),
    chartBox("Puntuación de oportunidad", d.score_history.map((h) => [h.ts, h.opp]), "#35d07f", (v) => v.toFixed(0)),
    chartBox("Puntuación de riesgo", d.score_history.map((h) => [h.ts, h.risk]), "#ff5d6c", (v) => v.toFixed(0)));
  body.push(el("h3", {}, "Historial de cambios de puntuación"),
    d.score_history.length ? el("table", { class: "mini" }, el("tbody", {}, d.score_history.slice().reverse().slice(0, 15).map((h) =>
      el("tr", {}, el("td", {}, new Date(h.ts).toLocaleString("es")), el("td", {}, `Oport. ${h.opp}`), el("td", {}, `Riesgo ${h.risk}`), el("td", {}, h.signal))))) : el("p", { class: "muted" }, "Sin historial todavía."),
    el("h3", {}, "Alertas de esta moneda"),
    d.alerts.length ? el("ul", {}, d.alerts.map((x) => el("li", {}, `${new Date(x.ts).toLocaleString("es")} — ${x.title}: ${x.message}`))) : el("p", { class: "muted" }, "Sin alertas."),
    el("p", { class: "muted" }, a.disclaimer));
  $("drawerBody").replaceChildren(...body);
}

/* ---------- ajustes ---------- */
const LABELS = { nueva_moneda: "Aparece una moneda nueva", volumen_sube: "El volumen/actividad se acelera", oportunidad_temprana: "Se detecta una oportunidad temprana",
  cambio_puntuacion: "Cambio importante de puntuación", riesgo_critico: "Riesgo crítico (posible estafa)", caida_fuerte: "Caída fuerte o pérdida de liquidez", fomo: "Entra en condiciones de FOMO (subida parabólica)" };
const TLABELS = { new_max_age_min: "Antigüedad máx. para avisar «nueva» (min)", volume_accel: "Aceleración de volumen mínima (×)", min_volume_1h: "Volumen 1 h mínimo ($)",
  score_delta: "Cambio de puntuación que avisa (puntos)", cooldown_min: "No repetir la misma alerta durante (min)", min_liquidity_new: "Liquidez mínima para avisar «nueva» ($)" };
let adminToken = ""; try { adminToken = sessionStorage.getItem("radarAdmin") || ""; } catch (e) {}
async function openSettings() {
  const j = await api("/api/settings"), s = j.settings;
  $("tgState").textContent = j.telegram_configured ? "Telegram está configurado en el servidor." : "Telegram NO está configurado: añade TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID al archivo .env y reinicia. Las alertas igualmente se registran en la pestaña «Alertas».";
  $("alertToggles").replaceChildren(...Object.keys(LABELS).map((k) => el("label", { class: "row" }, el("input", { type: "checkbox", "data-k": k, ...(s.alerts[k] ? { checked: "" } : {}) }), LABELS[k])));
  $("thresholds").replaceChildren(...Object.keys(TLABELS).map((k) => el("label", { class: "row" }, el("input", { type: "number", step: "any", "data-t": k, value: s.thresholds[k], style: "width:110px" }), TLABELS[k])));
  $("tgEnabled").checked = !!s.telegram_enabled; $("settingsMsg").textContent = "";
  $("settings").showModal();
}
async function post(path, body) {
  const go = () => api(path, { method: "POST", headers: { "Content-Type": "application/json", ...(adminToken ? { "X-Admin-Token": adminToken } : {}) }, body: JSON.stringify(body) });
  try { return await go(); } catch (e) {
    if (e.status === 403) { const t = prompt("Acceso restringido. Introduce RADAR_ADMIN_TOKEN:"); if (!t) throw e; adminToken = t; try { sessionStorage.setItem("radarAdmin", t); } catch (_) {} return go(); }
    throw e;
  }
}
async function saveSettings() {
  const alerts = {}, thresholds = {};
  document.querySelectorAll("[data-k]").forEach((i) => (alerts[i.dataset.k] = i.checked));
  document.querySelectorAll("[data-t]").forEach((i) => { const v = parseFloat(i.value); if (!isNaN(v)) thresholds[i.dataset.t] = v; });
  try { await post("/api/settings", { alerts, thresholds, telegram_enabled: $("tgEnabled").checked }); $("settingsMsg").textContent = "Guardado."; }
  catch (e) { $("settingsMsg").textContent = "No se pudo guardar: " + e.message; }
}

/* ---------- eventos ---------- */
["q", "fChain", "fClass", "fSignal", "fAge", "fLiq", "fVol", "fOpp", "fRisk"].forEach((id) => $(id).addEventListener("input", () => { state.page = 0; renderTable(); }));
$("btnAll").addEventListener("click", () => { document.querySelectorAll("#filters input, #filters select").forEach((i) => (i.value = "")); state.tab = "todas"; state.page = 0; render(); });
$("btnRec").addEventListener("click", () => { $("fOpp").value = 50; $("fRisk").value = 45; $("fLiq").value = 10000; state.page = 0; renderTable(); });
$("btnRefresh").addEventListener("click", async () => { try { await post("/api/refresh", {}); $("updated").textContent = "Actualización solicitada…"; setTimeout(refresh, 4000); } catch (e) { $("updated").textContent = "No se pudo solicitar: " + e.message; } });
$("btnSettings").addEventListener("click", () => openSettings().catch((e) => alert(e.message)));
$("btnSettingsSave").addEventListener("click", saveSettings);
$("btnSettingsClose").addEventListener("click", () => $("settings").close());
$("btnTgTest").addEventListener("click", async () => { try { const r = await post("/api/telegram/test", {}); $("settingsMsg").textContent = "Resultado: " + r.result; } catch (e) { $("settingsMsg").textContent = e.message; } });
$("drawerClose").addEventListener("click", () => { $("drawer").hidden = true; state.openKey = null; });
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("drawer").hidden) $("drawerClose").click(); });

refresh();
setInterval(refresh, 10000);
setInterval(() => { if (!state.offline) { renderHeader(); } }, 1000);
