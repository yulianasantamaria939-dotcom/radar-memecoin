import json
import time

import pytest

from radar import alerts, chains, normalize, scoring, security
from radar.http import FetchError, Fetcher, SourceStatus
from tests import fixtures as fx


# ---------------- HTTP ----------------
def make_fetcher(responses, sleeps=None):
    calls = []
    sleeps = sleeps if sleeps is not None else []

    def transport(url, headers, timeout, data=None):
        calls.append(url)
        r = responses.pop(0)
        if isinstance(r, Exception):
            raise r
        return r
    return Fetcher(SourceStatus(), transport=transport, sleep=sleeps.append, secrets=["SECRET123"]), calls, sleeps


def test_retry_on_429_then_ok():
    f, calls, sleeps = make_fetcher([(429, {"Retry-After": "3"}, b""), (200, {}, b'{"a":1}')])
    assert f.request_json("dexscreener", "https://x/y") == {"a": 1}
    assert len(calls) == 2 and 3.0 in sleeps
    assert f.status.snapshot()[0]["state"] in ("ok", "idle")


def test_error_recorded_and_secret_scrubbed():
    f, _, _ = make_fetcher([OSError("fallo SECRET123")] * 3)
    with pytest.raises(FetchError) as e:
        f.request_json("telegram", "https://api.telegram.org/botSECRET123/x")
    assert "SECRET123" not in str(e.value)
    st = {s["name"]: s for s in f.status.snapshot()}["telegram"]
    assert st["state"] == "error" and "SECRET123" not in (st["last_error"] or "")


def test_rate_limit_spaces_calls():
    f, _, sleeps = make_fetcher([(200, {}, b"{}")] * 3)
    t = [0.0]
    f.clock = lambda: t[0]
    for _ in range(3):
        f.request_json("geckoterminal", "https://x", interval=2.2, bucket="gt")
    assert sum(1 for s in sleeps if s > 0) >= 2  # la 2.ª y 3.ª llamada esperan


def test_404_not_retried():
    f, calls, _ = make_fetcher([(404, {}, b"")])
    with pytest.raises(FetchError):
        f.request_json("goplus", "https://x")
    assert len(calls) == 1


# ---------------- Normalización y deduplicación ----------------
def test_ds_and_gt_dedup_into_one_token():
    a = normalize.from_dexscreener_pair(fx.ds_pair())
    b = normalize.parse_gt_payload(fx.gt_payload())[0]
    assert a["key"] == b["key"] == f"base:{fx.EVM.lower()}"
    m = normalize.merge_tokens([a, b])
    assert set(m["sources"]) == {"dexscreener:pares", "geckoterminal:nuevos"}
    assert m["txns"]["h1"]["buyers"] == 90          # dato que solo trae GeckoTerminal
    assert m["txns"]["m5"]["buys"] == 10            # dato de DexScreener


def test_chain_mapping_and_unknown_chain_kept():
    t = normalize.parse_gt_payload(fx.gt_payload(network="eth"))[0]
    assert t["chain"] == "ethereum"
    t2 = normalize.from_dexscreener_pair(fx.ds_pair(chain="newchain"))
    assert t2["chain"] == "newchain"  # no se descartan redes desconocidas


def test_solana_address_case_preserved():
    t = normalize.from_dexscreener_pair(fx.ds_pair(chain="solana", token=fx.SOL))
    assert t["address"] == fx.SOL


def test_fomo_entry_parsing():
    t = normalize.from_fomo_entry({"rank": 1, "token": {"address": fx.SOL, "name": "F", "symbol": "F"},
                                   "network": "solana", "priceUsd": 0.5, "marketCapUsd": 1e6, "change24h": 12}, "trending")
    assert t["chain"] == "solana" and "fomo:trending" in t["sources"] and t["price_change"]["h24"] == 12
    assert normalize.from_fomo_entry({"token": {}}, "x") is None


def test_junk_payloads_ignored():
    assert normalize.parse_gt_payload(None) == [] and normalize.parse_gt_payload({"data": [None, 5]}) == []
    assert normalize.from_dexscreener_pair({"chainId": "base"}) is None


# ---------------- Seguridad ----------------
def test_goplus_ok_parsed():
    s = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    assert s["available"] and s["honeypot"] is False and s["sell_tax"] == 0.02
    assert s["lp_locked_pct"] == pytest.approx(90) and round(s["top10_pct"]) == 8


def test_goplus_empty_is_unavailable_not_safe():
    s = security.parse_goplus_evm(None)
    assert s["available"] is False and s["honeypot"] is None


def test_solana_rpc_authorities():
    r = {"result": {"value": {"data": {"parsed": {"info": {"mintAuthority": "abc", "freezeAuthority": None}}}}}}
    s = security.parse_solana_rpc_mint(r)
    assert s["mintable"] is True and s["freezable"] is False
    assert security.parse_solana_rpc_mint({"result": {"value": None}})["available"] is False


# ---------------- Puntuación ----------------
def tok(**kw):
    t = normalize.from_dexscreener_pair(fx.ds_pair(**kw))
    return t


def test_honeypot_is_scam_and_no_entry():
    sec = security.parse_goplus_evm(fx.goplus_honeypot()["result"][fx.EVM.lower()])
    a = scoring.analyze(tok(), sec, [], fx.NOW)
    assert a["classification"] == "posible_estafa" and a["signal"] == "NO ENTRAR" and a["risk"] == 100
    assert a["levels"] is None


def test_scores_independent_and_bounded():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    a = scoring.analyze(tok(), sec, [], fx.NOW)
    assert 0 <= a["opportunity"] <= 100 and 0 <= a["risk"] <= 100
    assert a["opportunity"] >= 55 and a["risk"] < 45          # buena opp, bajo riesgo
    assert a["opportunity_factors"] and a["positives"]


def test_no_security_never_entry_and_confidence_lower():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    with_sec = scoring.analyze(tok(), sec, [], fx.NOW)
    without = scoring.analyze(tok(), None, [], fx.NOW)
    assert without["signal"] != "ENTRADA POTENCIAL" and without["classification"] != "oportunidad_temprana"
    assert without["confidence"] < with_sec["confidence"]
    assert any("análisis de contrato" in m for m in without["missing"])
    assert any(f["level"] == "desconocido" for f in without["risk_flags"])


def test_missing_data_does_not_crash_and_is_reported():
    t = normalize.from_dexscreener_pair({"chainId": "base", "baseToken": {"address": fx.EVM}})
    a = scoring.analyze(t, None, [], fx.NOW)
    assert a["stage"] == "sin_datos" and a["missing"] and a["signal"] in ("ESPERAR", "NO ENTRAR")


def test_liquidity_drop_detected_and_confirmed():
    hist = [{"ts": fx.NOW - 20 * 60000, "liq": 100000}]
    a = scoring.analyze(tok(liq=40000), None, hist, fx.NOW)
    f = [x for x in a["risk_flags"] if x["code"] == "perdida_liquidez"][0]
    assert f["level"] == "confirmado" and "perdida_liquidez" in a["alerts"] and a["signal"] == "POSIBLE SALIDA"


def test_parabolic_is_fomo_alto():
    t = tok(priceChange={"m5": 40, "h1": 200, "h6": 400, "h24": 400})
    a = scoring.analyze(t, security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()]), [], fx.NOW)
    assert a["stage"] == "fomo" and "subida_parabolica" in a["alerts"] and a["signal"] == "FOMO ALTO"


def test_no_sells_pattern_flagged():
    t = tok(txns={"m5": {"buys": 5, "sells": 0}, "h1": {"buys": 80, "sells": 0}, "h6": {"buys": 80, "sells": 0}, "h24": {"buys": 80, "sells": 0}})
    a = scoring.analyze(t, None, [], fx.NOW)
    assert any(f["code"] == "sin_ventas" for f in a["risk_flags"])


def test_entry_levels_present_and_labeled():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    a = scoring.analyze(tok(), sec, [], fx.NOW)
    if a["signal"] in ("ENTRADA POTENCIAL", "ESPERAR"):
        lv = a["levels"]
        assert lv["invalidation"] < lv["entry_zone"][0] and "no son predicciones" in lv["note"].lower()
        assert all(x["risk_reward"] > 0 for x in lv["targets"])


def test_never_claims_safe():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    a = scoring.analyze(tok(), sec, [], fx.NOW)
    blob = json.dumps(a, ensure_ascii=False).lower()
    assert "es segura" not in blob and "sin riesgo" not in blob and "no es consejo financiero" in blob


# ---------------- Alertas ----------------
SETTINGS = {"telegram_enabled": True, "alerts": {k: True for k in alerts.KIND_TITLES}, "thresholds": dict(alerts.DEFAULT_SETTINGS["thresholds"])}


def test_new_coin_alert_only_if_recent():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    a_new = scoring.analyze(tok(created_min=10), sec, [], fx.NOW)
    assert any(e["kind"] == "nueva_moneda" for e in alerts.evaluate(tok(created_min=10), a_new, None, SETTINGS))
    a_old = scoring.analyze(tok(created_min=5000), sec, [], fx.NOW)
    assert not any(e["kind"] == "nueva_moneda" for e in alerts.evaluate(tok(created_min=5000), a_old, None, SETTINGS))


def test_alert_kinds_can_be_disabled():
    s = json.loads(json.dumps(SETTINGS)); s["alerts"]["nueva_moneda"] = False
    a = scoring.analyze(tok(created_min=10), None, [], fx.NOW)
    assert not any(e["kind"] == "nueva_moneda" for e in alerts.evaluate(tok(created_min=10), a, None, s))


def test_score_change_threshold():
    a = scoring.analyze(tok(), None, [], fx.NOW)
    prev = {"classification": a["classification"], "stage": a["stage"], "base_opp": a["opportunity"] - 20, "base_risk": a["risk"]}
    assert any(e["kind"] == "cambio_puntuacion" for e in alerts.evaluate(tok(), a, prev, SETTINGS))
    prev["base_opp"] = a["opportunity"] - 3
    assert not any(e["kind"] == "cambio_puntuacion" for e in alerts.evaluate(tok(), a, prev, SETTINGS))


def test_telegram_message_escapes_html():
    t = tok(); t["name"] = "<script>alert(1)</script>"
    a = scoring.analyze(t, None, [], fx.NOW)
    msg = alerts.format_message({"kind": "nueva_moneda", "reason": "<b>x</b>"}, t, a)
    assert "<script>" not in msg and "&lt;script&gt;" in msg and "&lt;b&gt;x" in msg
    assert fx.EVM.lower() in msg


def test_risk_never_zero_inherent_baseline():
    sec = security.parse_goplus_evm(fx.goplus_ok()["result"][fx.EVM.lower()])
    a = scoring.analyze(tok(), sec, [], fx.NOW)
    assert a["risk"] >= 10 and any(f["code"] == "riesgo_inherente" for f in a["risk_flags"])
