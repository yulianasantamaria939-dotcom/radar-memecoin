import json
import threading
import urllib.request
import urllib.error

import pytest

from radar.collector import Collector
from radar.config import Config
from radar.db import Database
from radar.http import Fetcher, SourceStatus
from radar.server import App, make_server
from radar.telegram import Telegram
from tests import fixtures as fx

SECRETS = {"TELEGRAM_BOT_TOKEN": "TGSECRET999", "TELEGRAM_CHAT_ID": "42", "FOMOAPI_KEY": "FOMOSECRET888",
           "GOPLUS_ACCESS_TOKEN": "GPSECRET777", "RADAR_ADMIN_TOKEN": "ADMINSECRET666", "RADAR_NETWORKS": "base,solana"}


class FakeWorld:
    """Simula las API (SOLO en pruebas). Registra cada llamada."""
    def __init__(self, fail=()):
        self.calls, self.fail, self.telegram = [], set(fail), []

    def transport(self, url, headers, timeout, data=None):
        self.calls.append(url)
        for f in self.fail:
            if f in url:
                return 500, {}, b"boom"
        j = lambda o: (200, {}, json.dumps(o).encode())
        if "geckoterminal" in url:
            return j(fx.gt_payload()) if "/networks/base/new_pools" in url else j({"data": []})
        if "token-profiles" in url:
            return j([{"chainId": "base", "tokenAddress": fx.EVM}, {"chainId": "solana", "tokenAddress": fx.SOL}])
        if "token-boosts" in url:
            return j([])
        if "/tokens/v1/base/" in url:
            return j([fx.ds_pair()])
        if "/tokens/v1/solana/" in url:
            return j([fx.ds_pair(chain="solana", token=fx.SOL, pair="solpair")])
        if "gopluslabs" in url and "/solana/" in url:
            return j({"code": 1, "result": {}})
        if "gopluslabs" in url:
            return j(fx.goplus_ok())
        if "mainnet-beta.solana" in url:
            return j({"result": {"value": {"data": {"parsed": {"info": {"mintAuthority": None, "freezeAuthority": None}}}}}})
        if "fomoapi" in url:
            return j({"board": "trending", "tokens": [{"rank": 1, "token": {"address": fx.SOL, "name": "Fomo Coin", "symbol": "FC"},
                                                      "network": "solana", "priceUsd": 0.1, "marketCapUsd": 100000, "change24h": 5}]})
        if "api.telegram.org" in url:
            self.telegram.append(json.loads(data))
            return j({"ok": True})
        return 404, {}, b""


def build(world, env=None):
    cfg = Config({**SECRETS, **(env or {}), "RADAR_DB": ":memory:"})
    f = Fetcher(SourceStatus(), transport=world.transport, sleep=lambda s: None, secrets=cfg.secrets())
    db = Database(":memory:")
    tg = Telegram(cfg, f)
    return cfg, db, f, tg, Collector(cfg, db, f, tg)


def test_full_cycle_dedup_fomo_alerts_and_no_dupes():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w)
    col.run_cycle()
    rows = {r["key"]: r for r in db.list_tokens()}
    assert set(rows) == {f"base:{fx.EVM.lower()}", f"solana:{fx.SOL}"}       # 3 fuentes -> 2 monedas únicas
    base = rows[f"base:{fx.EVM.lower()}"]
    assert {"geckoterminal:nuevos", "dexscreener:perfiles", "dexscreener:pares"} <= set(base["token"]["sources"])
    assert any(s.startswith("fomo") for s in rows[f"solana:{fx.SOL}"]["token"]["sources"])   # etiqueta FOMO
    assert base["analysis"]["opportunity"] is not None and base["analysis"]["risk_flags"] is not None
    # solana sin datos de GoPlus -> respaldo RPC (autoridades) o "no disponible", nunca "seguro"
    _, sec = db.get_security(f"solana:{fx.SOL}")
    assert sec["source"] == "solana_rpc" and sec["honeypot"] is None
    n1, sent1 = len(db.recent_alerts()), len(w.telegram)
    assert n1 > 0 and sent1 > 0
    assert all("TGSECRET999" not in json.dumps(m) for m in w.telegram)
    col.run_cycle()                                                              # mismo dato otra vez
    assert len(db.recent_alerts()) == n1 and len(w.telegram) == sent1           # sin duplicados
    assert sum("fomoapi" in c for c in w.calls) == 2                            # 2 tableros, solo 1 vez (cupo)
    assert db.count_tokens() == 2


def test_source_failure_is_isolated_and_reported():
    w = FakeWorld(fail=("geckoterminal",))
    cfg, db, f, tg, col = build(w)
    st = col.run_cycle()
    assert db.count_tokens() == 2                                                # DexScreener siguió funcionando
    gt = {s["name"]: s for s in f.status.snapshot()}["geckoterminal"]
    assert gt["state"] == "error" and "HTTP 500" in gt["last_error"]
    assert any("geckoterminal" in e for e in st["errors"])


def test_all_sources_down_does_not_crash_and_keeps_old_data():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w)
    col.run_cycle()
    before = {r["key"]: r["token"]["price_usd"] for r in db.list_tokens()}
    w.fail = {"geckoterminal", "dexscreener", "gopluslabs", "fomoapi", "solana"}
    st = col.run_cycle()
    assert st["errors"] and {r["key"]: r["token"]["price_usd"] for r in db.list_tokens()} == before


def test_no_fomo_key_means_no_fomo_calls():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w, {"FOMOAPI_KEY": ""})
    col.run_cycle()
    assert not any("fomoapi" in c for c in w.calls)
    assert not any(s.startswith("fomo") for r in db.list_tokens() for s in r["token"]["sources"])


def test_telegram_not_configured_still_records_alerts():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w, {"TELEGRAM_BOT_TOKEN": ""})
    col.run_cycle()
    assert db.recent_alerts() and not w.telegram
    assert all("Telegram sin configurar" in a["telegram"] for a in db.recent_alerts())


def test_telegram_cap_per_cycle():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w, {"RADAR_TELEGRAM_MAX_PER_CYCLE": "1"})
    col.run_cycle()
    sent = [a for a in db.recent_alerts() if a["telegram"] == "enviado"]
    assert len(sent) == 1 and any("límite por ciclo" in a["telegram"] for a in db.recent_alerts())


def test_settings_roundtrip_and_validation():
    db = Database(":memory:")
    s = db.set_settings({"alerts": {"nueva_moneda": False, "inventada": True}, "thresholds": {"score_delta": 30, "x": 1, "cooldown_min": "mal"}})
    assert s["alerts"]["nueva_moneda"] is False and "inventada" not in s["alerts"]
    assert s["thresholds"]["score_delta"] == 30 and s["thresholds"]["cooldown_min"] == 60 and "x" not in s["thresholds"]


def test_score_history_records_changes_only():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w)
    col.run_cycle(); col.run_cycle()
    assert len(db.score_history(f"base:{fx.EVM.lower()}")) == 1


# ---------------- Servidor ----------------
@pytest.fixture()
def server():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w)
    col.run_cycle()
    srv = make_server(App(cfg, db, col, f, tg), "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}", db
    srv.shutdown(); srv.server_close()


def get(url, headers=None):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=headers or {})) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def post(url, body, headers=None):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"Content-Type": "application/json", **(headers or {})}, method="POST")
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()


def test_api_never_leaks_secrets(server):
    base, db = server
    key = f"base:{fx.EVM.lower()}"
    texts = [get(base + p)[1] for p in ("/api/tokens", "/api/status", "/api/alerts", "/api/settings", "/api/token/" + key, "/")]
    for t in texts:
        for secret in ("TGSECRET999", "FOMOSECRET888", "GPSECRET777", "ADMINSECRET666"):
            assert secret not in t
    st = json.loads(get(base + "/api/status")[1])
    assert st["config"]["telegram_configured"] is True and st["config"]["fomo_configured"] is True


def test_api_tokens_returns_all_even_bad_ones(server):
    base, db = server
    rows = json.loads(get(base + "/api/tokens")[1])
    assert rows["count"] == 2 and all(r["opp"] is not None and r["risk"] is not None for r in rows["tokens"])
    assert any(r["is_fomo"] for r in rows["tokens"])
    detail = json.loads(get(base + "/api/token/" + rows["tokens"][0]["key"])[1])
    assert "analysis" in detail and "history" in detail and "alerts" in detail
    assert get(base + "/api/token/nope")[0] == 404


def test_static_serving_and_path_traversal(server):
    base, _ = server
    assert get(base + "/")[0] == 200
    assert get(base + "/../run.py")[0] in (400, 404)
    assert get(base + "/%2e%2e/run.py")[0] == 404
    assert get(base + "/static/../.env.example")[0] == 404


def test_settings_post_local_ok_and_forwarded_blocked(server):
    base, db = server
    assert post(base + "/api/settings", {"alerts": {"fomo": False}})[0] == 200
    assert db.get_settings()["alerts"]["fomo"] is False
    assert post(base + "/api/settings", {"alerts": {"fomo": True}}, {"X-Forwarded-For": "8.8.8.8"})[0] == 403
    assert post(base + "/api/settings", {"alerts": {"fomo": True}}, {"X-Forwarded-For": "8.8.8.8", "X-Admin-Token": "ADMINSECRET666"})[0] == 200
    assert post(base + "/api/nope", {})[0] == 404


def test_status_marks_unconfigured_sources():
    w = FakeWorld()
    cfg, db, f, tg, col = build(w, {"FOMOAPI_KEY": "", "TELEGRAM_BOT_TOKEN": ""})
    srv = make_server(App(cfg, db, col, f, tg), "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        st = json.loads(get(f"http://127.0.0.1:{srv.server_address[1]}/api/status")[1])
        by = {s["name"]: s for s in st["sources"]}
        assert by["fomoapi"]["state"] == "sin_configurar" and by["telegram"]["state"] == "sin_configurar"
    finally:
        srv.shutdown(); srv.server_close()


def test_dead_source_circuit_breaker_limits_calls():
    w = FakeWorld(fail=("geckoterminal",))
    cfg, db, f, tg, col = build(w, {"RADAR_NETWORKS": "base,solana,ethereum,bsc,arbitrum,polygon,avalanche,optimism"})
    col.run_cycle()
    new_pool_calls = [c for c in w.calls if "new_pools" in c]
    assert len(new_pool_calls) <= 3 * 3 + 3   # 3 redes x 3 intentos (+ tendencia), no 8 redes
