"""RESPUESTAS DE EJEMPLO SOLO PARA PRUEBAS, con la forma documentada de cada API.
Nunca se usan en la aplicación real. Las direcciones/monedas son inventadas (TEST)."""
import time

NOW = int(time.time() * 1000)
EVM = "0xAbCdEf0000000000000000000000000000000001"
SOL = "TestSoLMint1111111111111111111111111111111111"
EVM2 = "0x0000000000000000000000000000000000000002"


def ds_pair(chain="base", token=EVM, pair="0xpair1", liq=40000, created_min=30, **kw):
    p = {"chainId": chain, "dexId": "uniswap", "pairAddress": pair,
         "baseToken": {"address": token, "name": "Test Coin", "symbol": "TST"},
         "quoteToken": {"symbol": "WETH"}, "priceUsd": "0.001",
         "txns": {"m5": {"buys": 10, "sells": 4}, "h1": {"buys": 120, "sells": 60}, "h6": {"buys": 200, "sells": 120}, "h24": {"buys": 200, "sells": 120}},
         "volume": {"m5": 5000, "h1": 30000, "h6": 40000, "h24": 40000},
         "priceChange": {"m5": 3, "h1": 20, "h6": 25, "h24": 25},
         "liquidity": {"usd": liq}, "fdv": 800000, "marketCap": 500000,
         "pairCreatedAt": NOW - created_min * 60000}
    p.update(kw)
    return p


def gt_payload(network="base", token=EVM, pool="0xpair1", name="Test Coin"):
    return {"data": [{"id": f"{network}_{pool}", "type": "pool", "attributes": {
        "name": "TST / WETH 1%", "address": pool, "base_token_price_usd": "0.00101",
        "pool_created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(NOW / 1000 - 1800)),
        "reserve_in_usd": "39000", "fdv_usd": "810000", "market_cap_usd": None,
        "price_change_percentage": {"m5": "3.1", "h1": "19", "h6": "24", "h24": "24"},
        "transactions": {"m5": {"buys": 10, "sells": 4, "buyers": 8, "sellers": 3},
                         "h1": {"buys": 118, "sells": 61, "buyers": 90, "sellers": 40}},
        "volume_usd": {"m5": "4900", "h1": "29000", "h6": "39000", "h24": "39000"}},
        "relationships": {"base_token": {"data": {"id": f"{network}_{token}", "type": "token"}},
                          "network": {"data": {"id": network}}, "dex": {"data": {"id": "uniswap-v3-base"}}}}],
        "included": [{"id": f"{network}_{token}", "type": "token",
                      "attributes": {"address": token, "name": name, "symbol": "TST"}}]}


def goplus_ok(addr=EVM):
    return {"code": 1, "message": "OK", "result": {addr.lower(): {
        "is_honeypot": "0", "buy_tax": "0.01", "sell_tax": "0.02", "is_open_source": "1", "is_mintable": "0",
        "hidden_owner": "0", "can_take_back_ownership": "0", "owner_change_balance": "0", "is_proxy": "0",
        "transfer_pausable": "0", "is_blacklisted": "0", "slippage_modifiable": "0", "cannot_sell_all": "0",
        "holder_count": "500", "creator_percent": "0.01", "owner_percent": "0",
        "holders": [{"address": "0xaaa", "percent": "0.05", "is_contract": "0"},
                    {"address": "0xbbb", "percent": "0.03", "is_contract": "0"}],
        "lp_holders": [{"address": "0x000000000000000000000000000000000000dEaD", "percent": "0.9", "is_locked": 1}]}}}


def goplus_honeypot(addr=EVM):
    d = goplus_ok(addr)
    d["result"][addr.lower()].update({"is_honeypot": "1", "sell_tax": "1"})
    return d
