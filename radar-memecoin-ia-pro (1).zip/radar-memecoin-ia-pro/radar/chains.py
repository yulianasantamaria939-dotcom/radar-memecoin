"""Catálogo de redes y mapeos entre proveedores.

Cada proveedor usa identificadores distintos para la misma red (p. ej. Ethereum es
`ethereum` en DexScreener y `eth` en GeckoTerminal). Aquí se unifican.
Redes que una API devuelva y que no estén en este catálogo se conservan igualmente
con el identificador del proveedor: no se descartan monedas por red desconocida.
"""
from urllib.parse import quote

# name: nombre visible | ds: id DexScreener | gt: id GeckoTerminal
# goplus: chain id de GoPlus (EVM) | explorer: plantilla de URL del token
CHAINS = {
    "solana": {"name": "Solana", "ds": "solana", "gt": "solana", "goplus": None,
               "explorer": "https://solscan.io/token/{a}"},
    "ethereum": {"name": "Ethereum", "ds": "ethereum", "gt": "eth", "goplus": "1",
                 "explorer": "https://etherscan.io/token/{a}"},
    "base": {"name": "Base", "ds": "base", "gt": "base", "goplus": "8453",
             "explorer": "https://basescan.org/token/{a}"},
    "bsc": {"name": "BNB Chain", "ds": "bsc", "gt": "bsc", "goplus": "56",
            "explorer": "https://bscscan.com/token/{a}"},
    "arbitrum": {"name": "Arbitrum", "ds": "arbitrum", "gt": "arbitrum", "goplus": "42161",
                 "explorer": "https://arbiscan.io/token/{a}"},
    "polygon": {"name": "Polygon", "ds": "polygon", "gt": "polygon_pos", "goplus": "137",
                "explorer": "https://polygonscan.com/token/{a}"},
    "avalanche": {"name": "Avalanche", "ds": "avalanche", "gt": "avax", "goplus": "43114",
                  "explorer": "https://snowtrace.io/token/{a}"},
    "optimism": {"name": "Optimism", "ds": "optimism", "gt": "optimism", "goplus": "10",
                 "explorer": "https://optimistic.etherscan.io/token/{a}"},
    "sui": {"name": "Sui", "ds": "sui", "gt": "sui-network", "goplus": None,
            "explorer": "https://suiscan.xyz/mainnet/coin/{a}"},
    "ton": {"name": "TON", "ds": "ton", "gt": "ton", "goplus": None,
            "explorer": "https://tonviewer.com/{a}"},
}

_DS = {v["ds"]: k for k, v in CHAINS.items()}
_GT = {v["gt"]: k for k, v in CHAINS.items()}


def get(chain):
    info = CHAINS.get(chain)
    if info:
        return info
    return {"name": str(chain).title(), "ds": chain, "gt": None, "goplus": None, "explorer": None}


def from_dexscreener(chain_id):
    if not chain_id:
        return None
    return _DS.get(chain_id, str(chain_id).lower())


def from_gt(network_id):
    if not network_id:
        return None
    return _GT.get(network_id, str(network_id).lower())


def is_evm(chain):
    return bool(get(chain).get("goplus"))


def is_solana(chain):
    return chain == "solana"


def supports_security(chain):
    return is_evm(chain) or is_solana(chain)


def norm_addr(chain, address):
    """EVM no distingue mayúsculas; Solana y otras redes sí."""
    a = str(address).strip()
    return a.lower() if is_evm(chain) else a


def explorer_url(chain, address):
    tpl = get(chain).get("explorer")
    return tpl.format(a=quote(str(address), safe="")) if tpl else None
