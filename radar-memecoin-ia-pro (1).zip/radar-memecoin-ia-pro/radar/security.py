"""Normaliza análisis de seguridad de contratos a una estructura común.

Todo campo es True/False/None; None = dato NO disponible (nunca se asume "seguro").
Fuentes: GoPlus (EVM y Solana) y, como respaldo en Solana, la RPC pública (autoridades del mint).
"""
from .util import num

BURN = {"0x000000000000000000000000000000000000dead", "0x0000000000000000000000000000000000000000"}

FIELDS = ("honeypot", "cannot_sell_all", "buy_tax", "sell_tax", "open_source", "mintable", "hidden_owner",
          "can_take_back_ownership", "owner_change_balance", "proxy", "transfer_pausable", "blacklist",
          "trading_cooldown", "slippage_modifiable", "selfdestruct", "external_call", "top10_pct",
          "top_holder_pct", "creator_pct", "owner_pct", "holder_count", "lp_locked_pct", "lp_known",
          "freezable", "non_transferable", "transfer_fee", "honeypot_same_creator")


def unavailable(reason):
    d = {k: None for k in FIELDS}
    d.update({"available": False, "source": None, "reason": reason})
    return d


def _b(v):
    if isinstance(v, dict):
        v = v.get("status")
    if v in ("1", 1, True):
        return True
    if v in ("0", 0, False):
        return False
    return None


def parse_goplus_evm(d):
    if not isinstance(d, dict) or not d:
        return unavailable("GoPlus aún no tiene datos de este token")
    s = unavailable("")
    s.update({"available": True, "source": "goplus", "reason": None})
    s["honeypot"] = _b(d.get("is_honeypot"))
    s["cannot_sell_all"] = _b(d.get("cannot_sell_all"))
    bt, st = num(d.get("buy_tax")), num(d.get("sell_tax"))
    s["buy_tax"], s["sell_tax"] = bt, st  # fracciones: 0.05 = 5 %
    s["open_source"] = _b(d.get("is_open_source"))
    s["mintable"] = _b(d.get("is_mintable"))
    s["hidden_owner"] = _b(d.get("hidden_owner"))
    s["can_take_back_ownership"] = _b(d.get("can_take_back_ownership"))
    s["owner_change_balance"] = _b(d.get("owner_change_balance"))
    s["proxy"] = _b(d.get("is_proxy"))
    s["transfer_pausable"] = _b(d.get("transfer_pausable"))
    s["blacklist"] = _b(d.get("is_blacklisted"))
    s["trading_cooldown"] = _b(d.get("trading_cooldown"))
    s["slippage_modifiable"] = _b(d.get("slippage_modifiable"))
    s["selfdestruct"] = _b(d.get("selfdestruct"))
    s["external_call"] = _b(d.get("external_call"))
    s["honeypot_same_creator"] = _b(d.get("honeypot_with_same_creator"))
    cp, op = num(d.get("creator_percent")), num(d.get("owner_percent"))
    s["creator_pct"] = cp * 100 if cp is not None else None
    s["owner_pct"] = op * 100 if op is not None else None
    s["holder_count"] = num(d.get("holder_count"))
    # Concentración: solo billeteras (no contratos ni quema). GoPlus lista los mayores holders.
    holders = d.get("holders")
    if isinstance(holders, list) and holders:
        pcts = sorted((num(h.get("percent"), 0) * 100 for h in holders
                       if isinstance(h, dict) and _b(h.get("is_contract")) is False
                       and str(h.get("address", "")).lower() not in BURN), reverse=True)
        s["top10_pct"] = sum(pcts[:10])
        s["top_holder_pct"] = pcts[0] if pcts else 0.0
    lps = d.get("lp_holders")
    if isinstance(lps, list) and lps:
        s["lp_known"] = True
        s["lp_locked_pct"] = sum(num(h.get("percent"), 0) * 100 for h in lps if isinstance(h, dict)
                                 and (_b(h.get("is_locked")) or str(h.get("address", "")).lower() in BURN))
    else:
        s["lp_known"] = False
    return s


def parse_goplus_solana(d):
    """Sigue la documentación de GoPlus para Solana; campos ausentes quedan en None."""
    if not isinstance(d, dict) or not d:
        return unavailable("GoPlus aún no tiene datos de este token")
    s = unavailable("")
    s.update({"available": True, "source": "goplus", "reason": None})
    s["mintable"] = _b(d.get("mintable"))
    s["freezable"] = _b(d.get("freezable"))
    s["non_transferable"] = _b(d.get("non_transferable"))
    tf = d.get("transfer_fee")
    s["transfer_fee"] = bool(tf) if isinstance(tf, (dict, list)) else _b(tf)
    s["holder_count"] = num(d.get("holder_count"))
    holders = d.get("holders")
    if isinstance(holders, list) and holders:
        pcts = sorted((num(h.get("percent"), 0) for h in holders if isinstance(h, dict)), reverse=True)
        if sum(pcts) <= 1.0001:  # solo si vienen como fracción; si no, no se arriesga una cifra errónea
            s["top10_pct"] = sum(pcts[:10]) * 100
            s["top_holder_pct"] = pcts[0] * 100
    return s


def parse_solana_rpc_mint(resp):
    """getAccountInfo(jsonParsed) del mint: autoridades de creación y congelación."""
    try:
        info = resp["result"]["value"]["data"]["parsed"]["info"]
    except (KeyError, TypeError):
        return unavailable("la RPC de Solana no devolvió datos del mint")
    s = unavailable("")
    s.update({"available": True, "source": "solana_rpc", "reason": None})
    s["mintable"] = info.get("mintAuthority") is not None
    s["freezable"] = info.get("freezeAuthority") is not None
    return s
