"""Reglas de alerta (puras, sin red) y formato del mensaje de Telegram."""
import html

from . import chains
from .util import fmt_usd, fmt_age

DEFAULT_SETTINGS = {
    "telegram_enabled": True,
    "alerts": {"nueva_moneda": True, "volumen_sube": True, "oportunidad_temprana": True, "cambio_puntuacion": True,
               "riesgo_critico": True, "caida_fuerte": True, "fomo": True},
    "thresholds": {"new_max_age_min": 120, "volume_accel": 3.0, "min_volume_1h": 1000, "score_delta": 15,
                   "cooldown_min": 60, "min_liquidity_new": 0},
}

KIND_TITLES = {
    "nueva_moneda": "🆕 Moneda nueva detectada",
    "volumen_sube": "📈 El volumen se acelera",
    "oportunidad_temprana": "🎯 Posible oportunidad temprana",
    "cambio_puntuacion": "🔀 Cambio importante de puntuación",
    "riesgo_critico": "🚨 Riesgo crítico",
    "caida_fuerte": "📉 Caída fuerte o pérdida de liquidez",
    "fomo": "🔥 Entró en condiciones de FOMO",
}


def evaluate(token, a, prev, settings):
    """Compara el análisis nuevo `a` con el estado previo `prev` (fila de BD o None).
    Devuelve lista de eventos {kind, severity, reason}. El enfriamiento lo aplica la BD."""
    th, on = settings["thresholds"], settings["alerts"]
    ev = []
    m = a["metrics"]
    vol1h = (token.get("volume") or {}).get("h1") or 0

    def add(kind, sev, reason):
        if on.get(kind):
            ev.append({"kind": kind, "severity": sev, "reason": reason})

    if prev is None:
        age, liq = m.get("age_min"), token.get("liquidity_usd") or 0
        if age is not None and age <= th["new_max_age_min"] and liq >= th["min_liquidity_new"]:
            add("nueva_moneda", "info", f"Par creado hace {fmt_age(age)}.")
    if m.get("volume_accel") and m["volume_accel"] >= th["volume_accel"] and vol1h >= th["min_volume_1h"]:
        add("volumen_sube", "info", f"Volumen 1 h ≈ {m['volume_accel']:.1f}× el ritmo previo ({fmt_usd(vol1h)}).")
    if a["classification"] == "oportunidad_temprana" and (prev is None or prev["classification"] != "oportunidad_temprana"):
        add("oportunidad_temprana", "info", "; ".join(a["signal_reasons"]) or "Cumple criterios de oportunidad temprana.")
    if a["classification"] == "posible_estafa" and (prev is None or prev["classification"] != "posible_estafa"):
        flags = [f["text"] for f in a["risk_flags"] if f["level"] == "confirmado"] or [f["text"] for f in a["risk_flags"][:2]]
        add("riesgo_critico", "critical", " ".join(flags) or "Riesgo crítico.")
    if "perdida_liquidez" in a["alerts"] or "caida_brusca" in a["alerts"]:
        txt = [f["text"] for f in a["risk_flags"] if f["code"] in ("perdida_liquidez", "caida_brusca")]
        add("caida_fuerte", "critical", " ".join(txt))
    if a["stage"] == "fomo" and (prev is None or prev["stage"] != "fomo"):
        add("fomo", "warn", "Subida acelerada: puede ser tarde para entrar.")
    if prev is not None and prev.get("base_opp") is not None:
        do, dr = a["opportunity"] - prev["base_opp"], a["risk"] - prev["base_risk"]
        if abs(do) >= th["score_delta"] or abs(dr) >= th["score_delta"]:
            add("cambio_puntuacion", "warn", f"Oportunidad {prev['base_opp']:.0f}→{a['opportunity']} · Riesgo {prev['base_risk']:.0f}→{a['risk']}.")
    return ev


def format_message(event, token, a):
    """Mensaje HTML para Telegram. Todo texto externo se escapa."""
    e = lambda x: html.escape(str(x if x is not None else "n/d"))
    chain = chains.get(token["chain"])["name"]
    vol = (token.get("volume") or {}).get("h24")
    lines = [f"<b>{e(KIND_TITLES.get(event['kind'], event['kind']))}</b>",
             f"<b>{e(token.get('name'))}</b> ({e(token.get('symbol'))}) · {e(chain)}",
             f"Contrato: <code>{e(token['address'])}</code>",
             f"Precio: {e(fmt_usd(token.get('price_usd')))} · Liquidez: {e(fmt_usd(token.get('liquidity_usd')))} · Vol 24h: {e(fmt_usd(vol))}",
             f"Oportunidad {a['opportunity']}/100 · Riesgo {a['risk']}/100 · {e(a['classification_label'])} · {e(a['signal'])}",
             f"Motivo: {e(event['reason'])}"]
    links = []
    if token.get("pair_address"):
        links.append(f'<a href="https://dexscreener.com/{e(chains.get(token["chain"])["ds"])}/{e(token["pair_address"])}">DexScreener</a>')
    ex = chains.explorer_url(token["chain"], token["address"])
    if ex:
        links.append(f'<a href="{e(ex)}">Explorador</a>')
    if links:
        lines.append(" · ".join(links))
    lines.append("<i>Análisis automático, no es consejo financiero. Verifica el contrato antes de operar.</i>")
    return "\n".join(lines)
