"""Cliente HTTP con límite de frecuencia por fuente, reintentos y estado de conexión."""
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

LABELS = {
    "dexscreener": "DEX Screener",
    "geckoterminal": "GeckoTerminal",
    "goplus": "GoPlus (seguridad)",
    "solana_rpc": "Solana RPC",
    "fomoapi": "FOMO (vía fomoapi.io, no oficial)",
    "telegram": "Telegram",
}


class FetchError(Exception):
    pass


class SourceStatus:
    def __init__(self):
        self._d = {}
        self._lock = threading.Lock()
        for name in LABELS:
            self._init(name)

    def _init(self, name):
        self._d.setdefault(name, {"name": name, "label": LABELS.get(name, name), "calls": 0, "errors": 0,
                                  "last_ok": None, "last_error": None, "last_error_at": None,
                                  "latency_ms": None})

    def ok(self, name, latency_ms):
        with self._lock:
            self._init(name)
            d = self._d[name]
            d["calls"] += 1
            d["last_ok"] = int(time.time() * 1000)
            d["latency_ms"] = int(latency_ms)

    def error(self, name, msg):
        with self._lock:
            self._init(name)
            d = self._d[name]
            d["calls"] += 1
            d["errors"] += 1
            d["last_error"] = msg
            d["last_error_at"] = int(time.time() * 1000)

    def snapshot(self):
        with self._lock:
            out = []
            for d in self._d.values():
                d = dict(d)
                if d["last_ok"] is None and d["last_error_at"] is None:
                    d["state"] = "idle"
                elif d["last_error_at"] and (d["last_ok"] is None or d["last_error_at"] > d["last_ok"]):
                    d["state"] = "error"
                else:
                    d["state"] = "ok"
                out.append(d)
            return out


def default_transport(url, headers, timeout, data=None):
    req = urllib.request.Request(url, headers=headers, data=data, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        try:
            body = e.read()
        except Exception:
            body = b""
        return e.code, dict(e.headers or {}), body


class Fetcher:
    def __init__(self, status=None, transport=None, sleep=time.sleep, clock=time.monotonic,
                 retries=2, timeout=15, secrets=()):
        self.status = status or SourceStatus()
        self.transport = transport or default_transport
        self.sleep = sleep
        self.clock = clock
        self.retries = retries
        self.timeout = timeout
        self.secrets = [s for s in secrets if s]
        self._next = {}
        self._lock = threading.Lock()

    def _scrub(self, msg):
        msg = str(msg)
        for s in self.secrets:
            msg = msg.replace(s, "***")
        return msg[:160]

    def _wait(self, bucket, interval):
        with self._lock:
            now = self.clock()
            slot = max(self._next.get(bucket, 0), now)
            self._next[bucket] = slot + interval
        delay = slot - now
        if delay > 0:
            self.sleep(delay)

    @staticmethod
    def _retry_after(headers):
        for k, v in (headers or {}).items():
            if k.lower() == "retry-after":
                try:
                    return float(v)
                except ValueError:
                    return None
        return None

    def request_json(self, source, url, params=None, headers=None, interval=0.5, bucket=None, json_body=None):
        """Devuelve el JSON o lanza FetchError. Nunca incluye la URL en el error
        (la URL de Telegram contiene el token del bot)."""
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, safe=",")
        bucket = bucket or source
        h = {"Accept": "application/json", "User-Agent": "RadarMemecoinIA/1.0"}
        h.update(headers or {})
        data = None
        if json_body is not None:
            data = json.dumps(json_body).encode("utf-8")
            h["Content-Type"] = "application/json"
        last = "error desconocido"
        for attempt in range(self.retries + 1):
            self._wait(bucket, interval)
            t0 = self.clock()
            try:
                status, rh, body = self.transport(url, h, self.timeout, data)
            except Exception as e:  # red caída, DNS, bloqueo de proxy, timeout
                reason = getattr(e, "reason", e)
                last = self._scrub(f"conexión fallida ({type(e).__name__}: {reason})")
                self.sleep(min(2 ** attempt, 8))
                continue
            latency = (self.clock() - t0) * 1000
            if status == 200:
                try:
                    payload = json.loads(body.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    last = "respuesta no es JSON válido"
                    break
                self.status.ok(source, latency)
                return payload
            last = f"HTTP {status}"
            if status in (429, 500, 502, 503, 504):
                self.sleep(min(self._retry_after(rh) or 2 ** (attempt + 1), 30))
                continue
            break
        self.status.error(source, last)
        raise FetchError(f"{source}: {last}")
