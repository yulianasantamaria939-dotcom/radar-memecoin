import datetime
import time


def num(x, default=None):
    """Convierte a float de forma segura. None/''/NaN/inf -> default."""
    if x is None or x == "" or isinstance(x, bool):
        return default
    try:
        v = float(x)
    except (TypeError, ValueError):
        return default
    if v != v or v in (float("inf"), float("-inf")):
        return default
    return v


def now_ms():
    return int(time.time() * 1000)


def iso_to_ms(s):
    if not s:
        return None
    try:
        return int(datetime.datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp() * 1000)
    except ValueError:
        return None


def fmt_usd(v):
    if v is None:
        return "n/d"
    if abs(v) >= 1e9:
        return f"${v / 1e9:.2f}B"
    if abs(v) >= 1e6:
        return f"${v / 1e6:.2f}M"
    if abs(v) >= 1e3:
        return f"${v / 1e3:.1f}K"
    if abs(v) >= 1:
        return f"${v:.2f}"
    return f"${v:.8f}".rstrip("0")


def fmt_age(minutes):
    if minutes is None:
        return "n/d"
    if minutes < 60:
        return f"{int(minutes)} min"
    if minutes < 60 * 48:
        return f"{minutes / 60:.1f} h"
    return f"{minutes / 1440:.1f} d"


def fmt_pct(v):
    return "n/d" if v is None else f"{v:+.1f}%"
