"""Servidor HTTP (biblioteca estándar). Sirve la interfaz y una API JSON de solo lectura,
más ajustes de alertas. Ningún endpoint devuelve claves ni credenciales."""
import hmac
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from . import chains
from .util import now_ms

STATIC = Path(__file__).resolve().parent.parent / "static"
MAX_BODY = 10_000


class App:
    def __init__(self, cfg, db, collector, fetcher, telegram):
        self.cfg, self.db, self.collector, self.fetcher, self.telegram = cfg, db, collector, fetcher, telegram


def _dex_url(t):
    if not t.get("pair_address"):
        return None
    return f"https://dexscreener.com/{chains.get(t['chain'])['ds']}/{t['pair_address']}"


def token_row(r, now):
    t, a = r["token"], r["analysis"]
    age = (now - t["pair_created_at"]) / 60000 if t.get("pair_created_at") else None
    flags = [f["text"] for f in a.get("risk_flags", []) if f["level"] in ("confirmado", "sospecha")][:2]
    parts = list(a.get("signal_reasons", []))[:1] + (flags or a.get("positives", [])[:1])
    return {
        "key": r["key"], "name": t.get("name"), "symbol": t.get("symbol"), "chain": t["chain"],
        "chain_name": chains.get(t["chain"])["name"], "address": t["address"], "pair_address": t.get("pair_address"),
        "dex": t.get("dex"), "age_min": age, "price": t.get("price_usd"), "liquidity": t.get("liquidity_usd"),
        "market_cap": t.get("market_cap") or t.get("fdv"), "volume24": (t.get("volume") or {}).get("h24"),
        "volume1h": (t.get("volume") or {}).get("h1"), "pc": t.get("price_change") or {},
        "opp": a.get("opportunity"), "risk": a.get("risk"), "classification": a.get("classification"),
        "classification_label": a.get("classification_label"), "stage": a.get("stage"),
        "stage_label": a.get("stage_label"), "signal": a.get("signal"), "alerts": a.get("alerts", []),
        "reason": " · ".join(parts), "confidence": a.get("confidence"), "confidence_label": a.get("confidence_label"),
        "first_seen": r["first_seen"], "updated": r["updated"], "last_seen": r["last_seen"],
        "sources": t.get("sources", []), "is_fomo": any(s.startswith("fomo") for s in t.get("sources", [])),
        "dex_url": _dex_url(t), "explorer_url": chains.explorer_url(t["chain"], t["address"]),
    }


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        server_version = "RadarMemecoinIA"

        def log_message(self, *a):  # silencio: las URL de la API no llevan secretos, pero evitamos ruido
            pass

        # ---------- utilidades ----------
        def _send(self, code, body, ctype="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'")
            self.end_headers()
            self.wfile.write(data)

        def _is_admin(self):
            tok = self.headers.get("X-Admin-Token", "")
            if app.cfg.admin_token and tok and hmac.compare_digest(tok, app.cfg.admin_token):
                return True
            local = self.client_address[0] in ("127.0.0.1", "::1")
            return local and "X-Forwarded-For" not in self.headers

        # ---------- GET ----------
        def do_GET(self):
            u = urlparse(self.path)
            path = unquote(u.path)
            q = parse_qs(u.query)
            now = now_ms()
            if path == "/api/health":
                return self._send(200, {"ok": True})
            if path == "/api/tokens":
                rows = [token_row(r, now) for r in app.db.list_tokens()]
                return self._send(200, {"now": now, "count": len(rows), "updated_at": app.collector.state["last_finished"],
                                        "tokens": rows})
            if path.startswith("/api/token/"):
                key = path[len("/api/token/"):]
                r = app.db.get_token(key)
                if not r:
                    return self._send(404, {"error": "moneda no encontrada"})
                _, sec = app.db.get_security(key)
                return self._send(200, {
                    "row": token_row(r, now), "token": r["token"], "analysis": r["analysis"], "security": sec,
                    "history": app.db.history(key, now - 72 * 3600_000), "score_history": app.db.score_history(key),
                    "alerts": app.db.recent_alerts(50, key)})
            if path == "/api/alerts":
                try:
                    limit = max(1, min(500, int(q.get("limit", ["100"])[0])))
                except ValueError:
                    limit = 100
                return self._send(200, {"alerts": app.db.recent_alerts(limit)})
            if path == "/api/status":
                return self._send(200, self._status())
            if path == "/api/settings":
                return self._send(200, {"settings": app.db.get_settings(), "telegram_configured": app.telegram.configured})
            return self._static(path)

        def _status(self):
            srcs = app.fetcher.status.snapshot()
            for s in srcs:
                if s["name"] == "fomoapi" and not app.cfg.fomo_key:
                    s["state"] = "sin_configurar"
                    s["note"] = "Falta FOMOAPI_KEY (clave gratuita de fomoapi.io). FOMO no tiene API oficial."
                if s["name"] == "telegram" and not app.cfg.telegram_configured:
                    s["state"] = "sin_configurar"
                    s["note"] = "Faltan TELEGRAM_BOT_TOKEN y TELEGRAM_CHAT_ID en .env"
            return {"now": now_ms(), "cycle": app.collector.state, "sources": srcs, "config": app.cfg.public(),
                    "tokens_total": app.db.count_tokens()}

        def _static(self, path):
            rel = "index.html" if path in ("/", "") else path.lstrip("/")
            if rel.startswith("static/"):
                rel = rel[len("static/"):]
            f = (STATIC / rel).resolve()
            if STATIC.resolve() not in f.parents or not f.is_file():
                return self._send(404, {"error": "no encontrado"})
            ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript",):
                ctype += "; charset=utf-8"
            return self._send(200, f.read_bytes(), ctype)

        # ---------- POST ----------
        def do_POST(self):
            path = urlparse(self.path).path
            if not self._is_admin():
                return self._send(403, {"error": "acceso restringido: usa el equipo local o envía X-Admin-Token (RADAR_ADMIN_TOKEN)"})
            try:
                n = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                n = 0
            if n > MAX_BODY:
                return self._send(413, {"error": "cuerpo demasiado grande"})
            try:
                body = json.loads(self.rfile.read(n) or b"{}") if n else {}
            except ValueError:
                return self._send(400, {"error": "JSON inválido"})
            if not isinstance(body, dict):
                return self._send(400, {"error": "se esperaba un objeto JSON"})
            if path == "/api/settings":
                return self._send(200, {"settings": app.db.set_settings(body)})
            if path == "/api/refresh":
                app.collector.trigger()
                return self._send(200, {"ok": True})
            if path == "/api/telegram/test":
                if not app.telegram.configured:
                    return self._send(400, {"error": "Telegram no está configurado en el servidor (.env)"})
                return self._send(200, {"result": app.telegram.send("✅ Prueba de Radar Memecoin IA PRO: Telegram funciona.")})
            return self._send(404, {"error": "no encontrado"})

    return Handler


def make_server(app, host, port):
    return ThreadingHTTPServer((host, port), make_handler(app))
