"""Configuración desde variables de entorno / archivo .env (solo en el servidor).

Las claves y credenciales NUNCA se envían al navegador: `public()` solo expone
valores no secretos y booleanos como `telegram_configured`.
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def load_env(path=None):
    p = Path(path) if path else ROOT / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _int(env, key, default):
    try:
        return int(env.get(key, default))
    except (TypeError, ValueError):
        return default


class Config:
    def __init__(self, env=None):
        e = env if env is not None else os.environ
        self.host = e.get("RADAR_HOST", "127.0.0.1")
        self.port = _int(e, "RADAR_PORT", 8000)
        self.db_path = e.get("RADAR_DB", str(ROOT / "data" / "radar.db"))
        default_nets = "solana,ethereum,base,bsc,arbitrum,polygon,avalanche,optimism,sui,ton"
        self.networks = [x.strip() for x in e.get("RADAR_NETWORKS", default_nets).split(",") if x.strip()]
        self.interval = max(20, _int(e, "RADAR_INTERVAL_SECONDS", 60))
        # Secretos (solo servidor)
        self.telegram_token = e.get("TELEGRAM_BOT_TOKEN", "").strip()
        self.telegram_chat = e.get("TELEGRAM_CHAT_ID", "").strip()
        self.admin_token = e.get("RADAR_ADMIN_TOKEN", "").strip()
        self.goplus_token = e.get("GOPLUS_ACCESS_TOKEN", "").strip()
        self.fomo_key = e.get("FOMOAPI_KEY", "").strip()
        self.fomo_interval = max(600, _int(e, "RADAR_FOMO_INTERVAL_SECONDS", 10800))  # 3 h: cuida el cupo gratis
        self.fomo_boards = [b.strip() for b in e.get("RADAR_FOMO_BOARDS", "trending,graduated").split(",") if b.strip()]
        self.solana_rpc = e.get("SOLANA_RPC_URL", "https://api.mainnet-beta.solana.com").strip()
        # Límites por ciclo (protegen los límites de las API)
        self.enrich_max = _int(e, "RADAR_ENRICH_MAX", 240)
        self.refresh_max = _int(e, "RADAR_REFRESH_MAX", 150)
        self.security_max = _int(e, "RADAR_SECURITY_MAX", 20)
        self.solana_rpc_max = _int(e, "RADAR_SOLANA_RPC_MAX", 5)
        self.telegram_max_per_cycle = _int(e, "RADAR_TELEGRAM_MAX_PER_CYCLE", 8)

    @property
    def telegram_configured(self):
        return bool(self.telegram_token and self.telegram_chat)

    def secrets(self):
        return [s for s in (self.telegram_token, self.goplus_token, self.admin_token, self.fomo_key) if s]

    def public(self):
        return {
            "networks": self.networks,
            "interval_seconds": self.interval,
            "telegram_configured": self.telegram_configured,
            "goplus_key_configured": bool(self.goplus_token),
            "fomo_configured": bool(self.fomo_key),
            "admin_token_required_remote": bool(self.admin_token),
        }
