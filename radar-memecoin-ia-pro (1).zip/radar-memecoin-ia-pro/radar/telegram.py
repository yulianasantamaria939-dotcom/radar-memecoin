"""Envío de mensajes por Telegram. El token vive solo en el servidor (variables de entorno)."""
from .http import FetchError


class Telegram:
    def __init__(self, cfg, fetcher):
        self.cfg, self.fetcher = cfg, fetcher

    @property
    def configured(self):
        return self.cfg.telegram_configured

    def send(self, text):
        """Devuelve 'enviado' o un texto de error (sin secretos)."""
        if not self.configured:
            return "no configurado"
        url = f"https://api.telegram.org/bot{self.cfg.telegram_token}/sendMessage"
        body = {"chat_id": self.cfg.telegram_chat, "text": text[:4000], "parse_mode": "HTML",
                "disable_web_page_preview": True}
        try:
            r = self.fetcher.request_json("telegram", url, json_body=body, interval=1.1, bucket="telegram")
        except FetchError as e:
            return f"error: {e}"
        return "enviado" if isinstance(r, dict) and r.get("ok") else "error: respuesta no válida"
