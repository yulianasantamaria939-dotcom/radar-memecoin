"""Ciclo de recolección: descubrir -> enriquecer -> seguridad -> analizar -> guardar -> alertar.

Cada fuente falla de forma independiente: un error de una API se registra y el ciclo continúa
con las demás. El radar solo analiza y alerta; no compra ni vende.
"""
import threading
import time
from collections import defaultdict

from . import alerts as alerts_mod, chains, normalize, scoring, security, sources
from .http import FetchError
from .util import now_ms

SECURITY_TTL_NEW_MS = 30 * 60_000       # monedas < 24 h: revisar cada 30 min
SECURITY_TTL_OLD_MS = 6 * 3600_000
SECURITY_RETRY_MS = 10 * 60_000         # si no hubo datos, reintentar a los 10 min
REFRESH_MAX_AGE_MS = 7 * 86400_000


class Collector:
    def __init__(self, cfg, db, fetcher, telegram, clock=now_ms):
        self.cfg, self.db, self.f, self.tg, self.clock = cfg, db, fetcher, telegram, clock
        self.state = {"cycles": 0, "running": False, "last_started": None, "last_finished": None,
                      "last_seconds": None, "tokens_seen": 0, "new_tokens": 0, "alerts_created": 0, "errors": []}
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread = None
        self._fomo_last = 0
        self._lock = threading.Lock()

    # ------------------------------------------------------------ descubrimiento
    def _add(self, obs, t):
        if t:
            obs.setdefault(t["key"], []).append(t)

    def _discover(self, obs, errors):
        gt_fails = 0
        for net in self.cfg.networks:
            gt = chains.get(net).get("gt")
            if not gt:
                continue
            if gt_fails >= 3:  # la fuente parece caída: no gastar el ciclo reintentando red por red
                errors.append("geckoterminal: se omiten las redes restantes tras 3 fallos seguidos")
                break
            try:
                for t in normalize.parse_gt_payload(sources.gt_pools(self.f, "new_pools", gt), "geckoterminal:nuevos"):
                    self._add(obs, t)
                gt_fails = 0
            except FetchError as e:
                gt_fails += 1
                errors.append(str(e))
        try:
            for t in normalize.parse_gt_payload(sources.gt_pools(self.f, "trending_pools"), "geckoterminal:tendencia"):
                self._add(obs, t)
        except FetchError as e:
            errors.append(str(e))
        for fn, tag in ((sources.dexscreener_profiles, "dexscreener:perfiles"), (sources.dexscreener_boosts, "dexscreener:boosts")):
            try:
                for entry in fn(self.f):
                    self._add(obs, normalize.from_dexscreener_profile(entry, tag))
            except FetchError as e:
                errors.append(str(e))

    def _discover_fomo(self, obs, errors):
        """FOMO vía fomoapi.io (no oficial). Solo si hay clave y respetando el cupo gratuito."""
        if not self.cfg.fomo_key:
            return
        now = time.monotonic()
        if self._fomo_last and now - self._fomo_last < self.cfg.fomo_interval:
            return
        self._fomo_last = now
        for board in self.cfg.fomo_boards:
            try:
                payload = sources.fomoapi_board(self.f, board, self.cfg.fomo_key)
            except FetchError as e:
                errors.append(str(e))
                continue
            for entry in (payload or {}).get("tokens") or []:
                self._add(obs, normalize.from_fomo_entry(entry, board))

    def _enrich(self, obs, errors, keys, limit):
        by_chain = defaultdict(list)
        for k in keys[:limit]:
            t = obs[k][0]
            by_chain[t["chain"]].append(t["address"])
        for chain, addrs in by_chain.items():
            ds_chain = chains.get(chain)["ds"]
            for i in range(0, len(addrs), 30):
                batch = addrs[i:i + 30]
                wanted = {chains.norm_addr(chain, a) for a in batch}
                try:
                    pairs = sources.dexscreener_pairs(self.f, ds_chain, batch)
                except FetchError as e:
                    errors.append(str(e))
                    continue
                for p in pairs:
                    t = normalize.from_dexscreener_pair(p)
                    if t and t["chain"] == chain and t["address"] in wanted:
                        self._add(obs, t)

    # ------------------------------------------------------------ seguridad
    def _needs_security(self, t, now):
        if not chains.supports_security(t["chain"]):
            return False
        ts, sec = self.db.get_security(t["key"])
        if ts is None:
            return True
        age = scoring.age_minutes(t, now)
        ttl = SECURITY_TTL_NEW_MS if (age is not None and age < 1440) else SECURITY_TTL_OLD_MS
        if not sec.get("available"):
            ttl = SECURITY_RETRY_MS
        return now - ts > ttl

    def _security(self, merged, errors, now):
        todo = [t for t in merged.values() if self._needs_security(t, now)]
        todo.sort(key=lambda t: t.get("pair_created_at") or 0, reverse=True)  # primero las más nuevas
        todo = todo[:self.cfg.security_max]
        groups = defaultdict(list)
        for t in todo:
            groups[t["chain"]].append(t)
        for chain, toks in groups.items():
            for i in range(0, len(toks), 20):
                batch = toks[i:i + 20]
                addrs = [t["address"] for t in batch]
                try:
                    if chains.is_solana(chain):
                        res = (sources.goplus_solana(self.f, addrs, self.cfg.goplus_token or None) or {}).get("result") or {}
                        parse = security.parse_goplus_solana
                    else:
                        res = (sources.goplus_evm(self.f, chains.get(chain)["goplus"], addrs, self.cfg.goplus_token or None) or {}).get("result") or {}
                        parse = security.parse_goplus_evm
                except FetchError as e:
                    errors.append(str(e))
                    for t in batch:  # registrar "no disponible" para no martillar la API
                        self.db.put_security(t["key"], security.unavailable("el proveedor de seguridad no respondió"), now)
                    continue
                lower = {str(k).lower(): v for k, v in res.items()} if isinstance(res, dict) else {}
                for t in batch:
                    d = res.get(t["address"]) if isinstance(res, dict) else None
                    if d is None:
                        d = lower.get(t["address"].lower())
                    self.db.put_security(t["key"], parse(d), now)
        # Respaldo Solana: autoridades del mint vía RPC, solo si GoPlus no tuvo datos
        used = 0
        for t in groups.get("solana", []):
            if used >= self.cfg.solana_rpc_max:
                break
            _, sec = self.db.get_security(t["key"])
            if sec and not sec.get("available"):
                used += 1
                try:
                    r = security.parse_solana_rpc_mint(sources.solana_mint(self.f, self.cfg.solana_rpc, t["address"]))
                except FetchError as e:
                    errors.append(str(e))
                    continue
                if r.get("available"):
                    self.db.put_security(t["key"], r, now)

    # ------------------------------------------------------------ ciclo
    def run_cycle(self):
        with self._lock:
            return self._run_cycle()

    def _run_cycle(self):
        now = self.clock()
        t0 = time.monotonic()
        errors = []
        self.state.update(running=True, last_started=now)
        obs = {}
        self._discover(obs, errors)
        self._discover_fomo(obs, errors)
        discovered = set(obs)
        # refrescar también monedas ya conocidas y recientes que no aparecieron en este ciclo
        stale = [r for r in self.db.list_tokens() if r["key"] not in obs and now - r["first_seen"] < REFRESH_MAX_AGE_MS]
        stale.sort(key=lambda r: r["updated"])
        for r in stale[:self.cfg.refresh_max]:
            obs[r["key"]] = [normalize.bare(r["token"])]
        new_first = [k for k in obs if k in discovered]
        self._enrich(obs, errors, new_first + [k for k in obs if k not in discovered],
                     self.cfg.enrich_max + self.cfg.refresh_max)
        merged = {k: normalize.merge_tokens(v) for k, v in obs.items()}
        merged = {k: v for k, v in merged.items() if v}
        self._security(merged, errors, now)
        settings = self.db.get_settings()
        created, new_count = [], 0
        for key, t in merged.items():
            prev = self.db.get_token(key)
            if prev is None:
                new_count += 1
            if t.get("price_usd") is None and t.get("liquidity_usd") is None and prev and prev["token"].get("price_usd") is not None:
                # esta ronda no trajo métricas: conservar las anteriores, solo marcar visto
                self.db.touch(key, now)
                continue
            _, sec = self.db.get_security(key)
            hist = self.db.history(key, now - 3600_000)
            a = scoring.analyze(t, sec, hist, now)
            events = alerts_mod.evaluate(t, a, prev, settings)
            self.db.save_token(t, a, now)
            self.db.add_snapshot(key, now, t)
            self.db.add_score_point(key, now, a)
            cooldown = int(settings["thresholds"]["cooldown_min"] * 60_000)
            for ev in events:
                msg = alerts_mod.format_message(ev, t, a)
                aid = self.db.add_alert(key, ev["kind"], ev["severity"], alerts_mod.KIND_TITLES[ev["kind"]], ev["reason"], now, cooldown)
                if aid:
                    created.append((aid, msg, ev))
                    if ev["kind"] == "cambio_puntuacion":
                        self.db.set_base(key, a["opportunity"], a["risk"])
        self._notify(created, settings)
        self.db.prune(now)
        self.state.update(running=False, cycles=self.state["cycles"] + 1, last_finished=self.clock(),
                          last_seconds=round(time.monotonic() - t0, 1), tokens_seen=len(merged),
                          new_tokens=new_count, alerts_created=len(created), errors=errors[:20])
        return self.state

    def _notify(self, created, settings):
        if not created:
            return
        if not (self.tg.configured and settings["telegram_enabled"]):
            for aid, _, _ in created:
                self.db.set_alert_telegram(aid, "no enviado (Telegram sin configurar o desactivado)")
            return
        cap = self.cfg.telegram_max_per_cycle
        order = sorted(created, key=lambda c: {"critical": 0, "warn": 1, "info": 2}[c[2]["severity"]])
        for aid, msg, _ in order[:cap]:
            self.db.set_alert_telegram(aid, self.tg.send(msg))
        for aid, _, _ in order[cap:]:
            self.db.set_alert_telegram(aid, "no enviado (límite por ciclo; ver en el panel)")
        if len(order) > cap:
            self.tg.send(f"ℹ️ {len(order) - cap} alertas más en este ciclo. Revísalas en el panel del radar.")

    # ------------------------------------------------------------ hilo
    def start(self):
        if self._thread and self._thread.is_alive():
            return

        def loop():
            while not self._stop.is_set():
                try:
                    self.run_cycle()
                except Exception as e:  # nunca matar el hilo
                    self.state.update(running=False, errors=[f"ciclo falló: {type(e).__name__}: {e}"[:200]])
                self._wake.wait(self.cfg.interval)
                self._wake.clear()
        self._thread = threading.Thread(target=loop, daemon=True, name="collector")
        self._thread.start()

    def trigger(self):
        self._wake.set()

    def stop(self):
        self._stop.set()
        self._wake.set()
