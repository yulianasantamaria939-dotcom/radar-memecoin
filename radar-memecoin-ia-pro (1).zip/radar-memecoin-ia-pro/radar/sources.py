"""Llamadas a las API públicas. Solo endpoints documentados; sin claves obligatorias.

DexScreener   https://docs.dexscreener.com/api/reference   (perfiles/boosts 60/min; pares 300/min)
GeckoTerminal https://api.geckoterminal.com/docs            (30/min en el plan gratuito)
GoPlus        https://docs.gopluslabs.io                    (límites según plan; clave opcional)
Solana RPC    JSON-RPC estándar (getAccountInfo)

FOMO: la app NO tiene API pública oficial. Se usa fomoapi.io (terceros, no afiliada a FOMO), que
requiere clave gratuita (FOMOAPI_KEY; ~1.000 consultas/mes y 20/min). Si no hay clave, la fuente
queda "sin configurar": no se simula nada.
"""
from urllib.parse import quote

DS = "https://api.dexscreener.com"
GT = "https://api.geckoterminal.com/api/v2"
GOPLUS = "https://api.gopluslabs.io/api/v1"
GT_HEADERS = {"Accept": "application/json;version=20230302"}


def dexscreener_profiles(f):
    d = f.request_json("dexscreener", f"{DS}/token-profiles/latest/v1", interval=1.1, bucket="ds-profiles")
    return d if isinstance(d, list) else []


def dexscreener_boosts(f):
    d = f.request_json("dexscreener", f"{DS}/token-boosts/latest/v1", interval=1.1, bucket="ds-boosts")
    return d if isinstance(d, list) else []


def dexscreener_pairs(f, ds_chain, addresses):
    """Hasta 30 direcciones por llamada. Devuelve la lista de pares."""
    url = f"{DS}/tokens/v1/{quote(ds_chain, safe='')}/{','.join(quote(a, safe='') for a in addresses)}"
    d = f.request_json("dexscreener", url, interval=0.25, bucket="ds-pairs")
    return d if isinstance(d, list) else []


def gt_pools(f, kind, network=None, page=1):
    """kind: 'new_pools' | 'trending_pools'. network=None -> todas las redes."""
    path = f"/networks/{quote(network, safe='')}/{kind}" if network else f"/networks/{kind}"
    return f.request_json("geckoterminal", GT + path, params={"include": "base_token", "page": page},
                          headers=GT_HEADERS, interval=2.2, bucket="gt")


def goplus_evm(f, chain_id, addresses, token=None):
    headers = {"Authorization": token} if token else None
    return f.request_json("goplus", f"{GOPLUS}/token_security/{chain_id}",
                          params={"contract_addresses": ",".join(addresses)}, headers=headers,
                          interval=1.2, bucket="goplus")


def goplus_solana(f, addresses, token=None):
    headers = {"Authorization": token} if token else None
    return f.request_json("goplus", f"{GOPLUS}/solana/token_security",
                          params={"contract_addresses": ",".join(addresses)}, headers=headers,
                          interval=1.2, bucket="goplus")


def solana_mint(f, rpc_url, mint):
    body = {"jsonrpc": "2.0", "id": 1, "method": "getAccountInfo", "params": [mint, {"encoding": "jsonParsed"}]}
    return f.request_json("solana_rpc", rpc_url, json_body=body, interval=1.0, bucket="solana_rpc")


def dexscreener_search(f, query):
    """Búsqueda por dirección/nombre; sirve para descubrir en qué red(es) existe un contrato."""
    d = f.request_json("dexscreener", f"{DS}/latest/dex/search", params={"q": query}, interval=0.25, bucket="ds-search")
    return (d or {}).get("pairs") or [] if isinstance(d, dict) else []


FOMOAPI = "https://api.fomoapi.io"


def fomoapi_board(f, board, key, limit=50):
    """board: 'trending' | 'graduated' | 'most-held'. Cuesta ~250 créditos por consulta."""
    return f.request_json("fomoapi", f"{FOMOAPI}/v2/leaderboard/tokens/{board}", params={"limit": limit},
                          headers={"Authorization": f"Bearer {key}"}, interval=3.5, bucket="fomoapi")
