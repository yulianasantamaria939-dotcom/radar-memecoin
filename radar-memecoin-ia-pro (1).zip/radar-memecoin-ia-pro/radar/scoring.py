"""Puntuación de oportunidad y de riesgo (independientes), señales y niveles calculados.

Principios:
- Dato ausente = "desconocido": nunca se interpreta como seguro. Reduce la confianza.
- Ningún texto afirma que una moneda sea segura.
- Los niveles de entrada/objetivo son cálculos por reglas sobre el precio actual, no predicciones.
"""
from .util import num, now_ms as _now, fmt_usd, fmt_age

CONF, SUS, UNK = "confirmado", "sospecha", "desconocido"

CLASS_LABELS = {"oportunidad_temprana": "Oportunidad temprana", "en_observacion": "En observación",
                "alto_riesgo": "Alto riesgo", "posible_estafa": "Posible estafa"}
STAGE_LABELS = {"apareciendo": "Apareciendo", "creciendo": "Empezando a crecer", "fomo": "FOMO / ya muy subida",
                "cayendo": "Cayendo", "sin_impulso": "Sin impulso claro", "sin_datos": "Sin datos suficientes"}
DISCLAIMER = ("Análisis automático con datos públicos, sin garantía. No es consejo financiero. "
              "Que no se detecten alertas NO significa que la moneda sea segura.")


def age_minutes(token, now=None):
    c = token.get("pair_created_at")
    if not c:
        return None
    return max(0.0, ((now or _now()) - c) / 60000.0)


def volume_accel(vol):
    h1, h6, m5 = vol.get("h1"), vol.get("h6"), vol.get("m5")
    if h1 is not None and h6 is not None and h6 > h1:
        prev = (h6 - h1) / 5
        if prev > 0:
            return h1 / prev
    if h1 and m5 is not None:
        return (m5 * 12) / h1
    return None


def buy_ratio(tx):
    for w in ("h1", "m5"):
        t = tx.get(w) or {}
        b, s = t.get("buys"), t.get("sells")
        if b is not None and s is not None and (b + s) > 0:
            return b / (b + s), int(b + s), w
    return None, 0, None


def liquidity_drop(history, liq_now, now, window_min=60):
    if liq_now is None or not history:
        return None
    ref = max((h["liq"] for h in history if h.get("liq") and h["ts"] >= now - window_min * 60000), default=None)
    if not ref or ref <= 0:
        return None
    return max(0.0, 1 - liq_now / ref)


def _flag(code, level, text, weight):
    return {"code": code, "level": level, "text": text, "weight": weight}


def security_flags(sec):
    """Devuelve (flags, missing). Solo usa lo que el proveedor devolvió."""
    f, missing = [], []
    if not sec or not sec.get("available"):
        reason = (sec or {}).get("reason") or "sin datos de seguridad"
        return [_flag("sin_seguridad", UNK, f"Contrato sin analizar: {reason}. Riesgo desconocido.", 15)], \
               ["análisis de contrato (honeypot, impuestos, permisos, propietarios)"]
    if sec.get("honeypot") is True:
        f.append(_flag("honeypot", CONF, "El proveedor marca el token como HONEYPOT (no se puede vender).", 100))
    if sec.get("cannot_sell_all") is True:
        f.append(_flag("no_vender_todo", CONF, "No es posible vender todo el saldo.", 40))
    if sec.get("non_transferable") is True:
        f.append(_flag("no_transferible", CONF, "El token no es transferible.", 100))
    st, bt = sec.get("sell_tax"), sec.get("buy_tax")
    if st is not None:
        if st >= 0.5:
            f.append(_flag("impuesto_venta_extremo", CONF, f"Impuesto de venta {st * 100:.0f}%: prácticamente imposible vender con ganancia.", 70))
        elif st >= 0.2:
            f.append(_flag("impuesto_venta_alto", SUS, f"Impuesto de venta alto: {st * 100:.0f}%.", 30))
        elif st >= 0.1:
            f.append(_flag("impuesto_venta_medio", SUS, f"Impuesto de venta elevado: {st * 100:.0f}%.", 12))
    else:
        missing.append("impuesto de venta")
    if bt is not None:
        if bt >= 0.5:
            f.append(_flag("impuesto_compra_extremo", CONF, f"Impuesto de compra {bt * 100:.0f}%.", 40))
        elif bt >= 0.2:
            f.append(_flag("impuesto_compra_alto", SUS, f"Impuesto de compra alto: {bt * 100:.0f}%.", 15))
    else:
        missing.append("impuesto de compra")
    if sec.get("open_source") is False:
        f.append(_flag("no_verificado", SUS, "Código del contrato no verificado públicamente.", 20))
    if sec.get("mintable") is True:
        f.append(_flag("mint", SUS, "Se pueden crear (mintear) más tokens: la oferta puede inflarse.", 25))
    if sec.get("freezable") is True:
        f.append(_flag("congelable", SUS, "Existe autoridad para congelar cuentas/operaciones.", 20))
    if sec.get("hidden_owner") is True:
        f.append(_flag("dueno_oculto", SUS, "Propietario oculto en el contrato.", 20))
    if sec.get("can_take_back_ownership") is True:
        f.append(_flag("recuperar_propiedad", SUS, "El creador puede recuperar la propiedad del contrato.", 20))
    if sec.get("owner_change_balance") is True:
        f.append(_flag("dueno_cambia_saldos", SUS, "El propietario puede modificar saldos.", 30))
    if sec.get("transfer_pausable") is True:
        f.append(_flag("pausable", SUS, "Las transferencias se pueden pausar.", 15))
    if sec.get("blacklist") is True:
        f.append(_flag("lista_negra", SUS, "Puede bloquear billeteras (lista negra).", 10))
    if sec.get("slippage_modifiable") is True:
        f.append(_flag("slippage_modificable", SUS, "Los impuestos/deslizamiento son modificables por el dueño.", 15))
    if sec.get("selfdestruct") is True:
        f.append(_flag("autodestruccion", SUS, "El contrato puede autodestruirse.", 25))
    if sec.get("proxy") is True:
        f.append(_flag("proxy", SUS, "Contrato proxy: su lógica puede cambiar.", 8))
    if sec.get("honeypot_same_creator") is True:
        f.append(_flag("creador_con_honeypot", SUS, "El creador ha lanzado otros tokens marcados como honeypot.", 25))
    if sec.get("transfer_fee") is True:
        f.append(_flag("comision_transferencia", SUS, "Tiene comisión de transferencia configurada.", 10))
    t10, t1 = sec.get("top10_pct"), sec.get("top_holder_pct")
    if t10 is not None:
        if t10 >= 80:
            f.append(_flag("concentracion_extrema", SUS, f"Las 10 mayores billeteras (sin contratos) tienen {t10:.0f}% del suministro.", 30))
        elif t10 >= 50:
            f.append(_flag("concentracion_alta", SUS, f"Las 10 mayores billeteras tienen {t10:.0f}% del suministro.", 20))
        elif t10 >= 30:
            f.append(_flag("concentracion_media", SUS, f"Las 10 mayores billeteras tienen {t10:.0f}% del suministro.", 10))
    else:
        missing.append("concentración de propietarios")
    if t1 is not None and t1 >= 20:
        f.append(_flag("billetera_dominante", SUS, f"Una sola billetera posee {t1:.0f}% del suministro.", 15))
    if (sec.get("creator_pct") or 0) >= 10:
        f.append(_flag("creador_retiene", SUS, f"El creador conserva {sec['creator_pct']:.0f}% del suministro.", 10))
    if sec.get("lp_known") is True:
        lk = sec.get("lp_locked_pct") or 0
        if lk < 50:
            f.append(_flag("liquidez_no_bloqueada", SUS, f"Solo {lk:.0f}% de la liquidez figura bloqueada/quemada: puede retirarse.", 15))
    elif sec.get("lp_known") is False and sec.get("source") == "goplus":
        missing.append("bloqueo de liquidez")
    if sec.get("honeypot") is None:
        missing.append("simulación de venta (honeypot)")
    return f, missing


def analyze(token, security=None, history=None, now=None):
    now = now or _now()
    history = history or []
    vol, pc, tx = token.get("volume") or {}, token.get("price_change") or {}, token.get("txns") or {}
    liq, price = token.get("liquidity_usd"), token.get("price_usd")
    mcap = token.get("market_cap") or token.get("fdv")
    age = age_minutes(token, now)
    accel = volume_accel(vol)
    ratio, ntx, ratio_w = buy_ratio(tx)
    m5, h1, h6, h24 = (pc.get(w) for w in ("m5", "h1", "h6", "h24"))
    buyers_h1 = (tx.get("h1") or {}).get("buyers")
    missing = []

    # ---------------- Oportunidad (0-100) ----------------
    fac = []

    def add(name, pts, mx, detail):
        fac.append({"name": name, "points": round(pts, 1), "max": mx, "detail": detail})

    if age is None:
        add("Antigüedad", 0, 20, "Antigüedad del par no disponible"); missing.append("antigüedad del par")
    else:
        pts = 20 if age < 30 else 17 if age < 120 else 14 if age < 360 else 10 if age < 1440 else 5 if age < 4320 else 0
        add("Antigüedad", pts, 20, f"Par de {fmt_age(age)}: cuanto más nuevo, más temprano")
    if liq is None:
        add("Liquidez", 0, 20, "Liquidez no disponible"); missing.append("liquidez")
    else:
        pts = 0 if liq < 1e3 else 4 if liq < 5e3 else 9 if liq < 15e3 else 14 if liq < 50e3 else 18 if liq < 250e3 else 20
        add("Liquidez", pts, 20, f"Liquidez {fmt_usd(liq)}")
    if accel is None:
        add("Aceleración de volumen", 0, 20, "Sin datos de volumen para medir aceleración"); missing.append("volumen por intervalos")
    else:
        pts = 20 if accel >= 3 else 16 if accel >= 2 else 11 if accel >= 1.3 else 6 if accel >= 0.8 else 2
        add("Aceleración de volumen", pts, 20, f"Volumen de la última hora ≈ {accel:.1f}× el ritmo previo")
    if ratio is None:
        add("Presión compradora", 0, 15, "Sin datos de compras/ventas"); missing.append("compras y ventas")
    elif ntx < 10:
        add("Presión compradora", 3, 15, f"Solo {ntx} operaciones: muestra muy pequeña")
    else:
        pts = 15 if ratio >= .65 else 11 if ratio >= .55 else 7 if ratio >= .48 else 3 if ratio >= .4 else 0
        add("Presión compradora", pts, 15, f"{ratio * 100:.0f}% de {ntx} operaciones son compras ({ratio_w})")
    ref = h1 if h1 is not None else m5
    if ref is None:
        add("Tendencia de precio", 0, 15, "Sin variación de precio"); missing.append("variación de precio")
    else:
        if ref > 100: pts, d = 3, "subida >100% en 1 h: probablemente tarde"
        elif ref > 40: pts, d = 9, "subida fuerte (>40%) en 1 h"
        elif ref >= 3: pts, d = 15, "subida moderada y sostenida"
        elif ref >= 0: pts, d = 8, "precio lateral"
        elif ref >= -10: pts, d = 5, "ligera caída"
        else: pts, d = 0, "caída marcada"
        add("Tendencia de precio", pts, 15, f"{ref:+.1f}%: {d}")
    if buyers_h1 is not None:
        pts = 10 if buyers_h1 >= 100 else 8 if buyers_h1 >= 40 else 5 if buyers_h1 >= 15 else 2 if buyers_h1 >= 5 else 0
        add("Participación", pts, 10, f"{int(buyers_h1)} compradores únicos en 1 h")
    else:
        n1 = ((tx.get("h1") or {}).get("buys") or 0) + ((tx.get("h1") or {}).get("sells") or 0)
        pts = 6 if n1 >= 200 else 4 if n1 >= 60 else 2 if n1 >= 15 else 0
        add("Participación", pts, 10, f"{int(n1)} operaciones en 1 h (compradores únicos no disponibles)")
        missing.append("compradores únicos")
    opp = round(min(100, sum(x["points"] for x in fac)))

    # ---------------- Riesgo (0-100) ----------------
    flags, sec_missing = security_flags(security)
    missing += sec_missing
    if liq is not None:
        if liq < 1e3: flags.append(_flag("liquidez_critica", SUS, f"Liquidez crítica ({fmt_usd(liq)}): casi imposible salir sin perder.", 20))
        elif liq < 5e3: flags.append(_flag("liquidez_baja", SUS, f"Liquidez muy baja ({fmt_usd(liq)}).", 12))
        elif liq < 15e3: flags.append(_flag("liquidez_limitada", SUS, f"Liquidez limitada ({fmt_usd(liq)}).", 5))
        if mcap and liq > 0 and mcap / liq > 200:
            flags.append(_flag("cap_vs_liquidez", SUS, "Capitalización >200× la liquidez: el precio no se sostendría al vender.", 10))
        if vol.get("h24") and liq > 0 and vol["h24"] / liq > 60:
            flags.append(_flag("volumen_artificial", SUS, "Volumen 24 h >60× la liquidez: posible volumen artificial.", 10))
    drop = liquidity_drop(history, liq, now)
    alerts = []
    if drop is not None and drop >= .3:
        w = 45 if drop >= .6 else 25
        flags.append(_flag("perdida_liquidez", CONF, f"La liquidez cayó {drop * 100:.0f}% en la última hora (medido).", w))
        alerts.append("perdida_liquidez")
    h1tx = tx.get("h1") or {}
    if (h1tx.get("buys") or 0) >= 20 and h1tx.get("sells") == 0:
        flags.append(_flag("sin_ventas", SUS, "Muchas compras y CERO ventas en 1 h: patrón típico de token no vendible.", 30))
    if (h1tx.get("buys") or 0) >= 50 and h1tx.get("buyers") is not None and h1tx["buyers"] <= 5:
        flags.append(_flag("pocas_billeteras", SUS, "Muchas compras provienen de muy pocas billeteras: posible compra coordinada.", 15))
    n1 = (h1tx.get("buys") or 0) + (h1tx.get("sells") or 0)
    if liq and vol.get("h1") and n1 >= 10 and (vol["h1"] / n1) > 0.25 * liq:
        flags.append(_flag("operaciones_grandes", SUS, "Operaciones promedio muy grandes frente a la liquidez: posible manipulación.", 8))
    if "volumen_artificial" in {x["code"] for x in flags} or "pocas_billeteras" in {x["code"] for x in flags} or "operaciones_grandes" in {x["code"] for x in flags}:
        alerts.append("posible_manipulacion")
    if h1 is not None and abs(h1) > 150:
        flags.append(_flag("volatilidad_extrema", SUS, f"Variación de {h1:+.0f}% en 1 h: volatilidad extrema.", 10))
    if (m5 is not None and m5 <= -20) or (h1 is not None and h1 <= -35):
        flags.append(_flag("caida_brusca", CONF, "Caída brusca de precio (medida).", 15))
        alerts.append("caida_brusca")
    if (m5 is not None and m5 >= 30) or (h1 is not None and h1 >= 150) or (h6 is not None and h6 >= 300):
        alerts.append("subida_parabolica")
    if age is not None and age < 10:
        flags.append(_flag("muy_nuevo", SUS, "Par con menos de 10 minutos: sin historial.", 8))
    if price is None:
        missing.append("precio")
    flags.append(_flag("riesgo_inherente", "inherente", "Toda memecoin es altamente especulativa y puede perder el 100% de su valor, aunque no haya alertas.", 10))
    risk = min(100, round(sum(x["weight"] for x in flags)))
    critical = [x for x in flags if x["code"] in ("honeypot", "no_transferible", "impuesto_venta_extremo", "no_vender_todo")]

    # ---------------- Confianza ----------------
    have = [("liq", liq is not None, 2), ("v1", vol.get("h1") is not None, 1), ("v6", vol.get("h6") is not None, 1),
            ("v24", vol.get("h24") is not None, 1), ("m5", m5 is not None, 1), ("h1", h1 is not None, 1),
            ("h24", h24 is not None, 1), ("tx", ratio is not None, 2), ("age", age is not None, 2),
            ("sec", bool(security and security.get("available")), 4), ("buyers", buyers_h1 is not None, 1),
            ("mcap", mcap is not None, 1)]
    conf = round(100 * sum(w for _, ok, w in have if ok) / sum(w for *_, w in have))
    conf_label = "baja" if conf < 40 else "media" if conf < 70 else "alta"

    # ---------------- Etapa ----------------
    if price is None and liq is None:
        stage = "sin_datos"
    elif "subida_parabolica" in alerts:
        stage = "fomo"
    elif (h1 is not None and h1 <= -20) or (m5 is not None and m5 <= -15):
        stage = "cayendo"
    elif age is not None and age < 60:
        stage = "apareciendo"
    elif h1 is not None and h1 >= 5 and accel is not None and accel >= 1.3:
        stage = "creciendo"
    else:
        stage = "sin_impulso"

    # ---------------- Clasificación ----------------
    sec_ok = bool(security and security.get("available"))
    if critical or risk >= 85:
        cls = "posible_estafa"
    elif risk >= 55:
        cls = "alto_riesgo"
    elif opp >= 55 and risk < 45 and sec_ok and age is not None and age <= 4320:
        cls = "oportunidad_temprana"
    else:
        cls = "en_observacion"

    # ---------------- Señal ----------------
    reasons, change = [], []
    if cls == "posible_estafa" or (cls == "alto_riesgo" and "perdida_liquidez" not in alerts):
        signal = "NO ENTRAR"
        reasons.append("Riesgo excesivo o señales de fraude" if cls == "posible_estafa" else "Riesgo alto")
        change.append("Un riesgo confirmado no desaparece con el precio; solo cambiaría si el proveedor corrige el dato."
                      if critical else f"El riesgo tendría que bajar de {risk} a menos de 55.")
    elif "perdida_liquidez" in alerts:
        signal = "POSIBLE SALIDA"; reasons.append("La liquidez está cayendo" + (" (y el riesgo ya es alto: no entrar)" if cls == "alto_riesgo" else ""))
        change.append("La liquidez debería estabilizarse (dejar de caer) durante varias actualizaciones.")
    elif stage == "fomo":
        signal = "FOMO ALTO"; reasons.append("Subida acelerada: comprar ahora puede ser llegar tarde")
        change.append("Pasaría a ESPERAR/ENTRADA si el precio se estabiliza o retrocede sin perder liquidez.")
    elif stage == "cayendo" or ((m5 is not None and m5 <= -8) and (h1 is not None and h1 <= 0)):
        signal = "POSIBLE SALIDA"; reasons.append("El impulso se está deteriorando")
        change.append("El precio debería dejar de caer y recuperar compras (más compras que ventas).")
    else:
        unmet = []
        if opp < 60: unmet.append(f"oportunidad {opp}/100 (se pide ≥60)")
        if risk >= 40: unmet.append(f"riesgo {risk}/100 (se pide <40)")
        if not sec_ok: unmet.append("sin análisis de contrato")
        if conf < 55: unmet.append(f"confianza {conf}% (se pide ≥55%)")
        if liq is None or liq < 10e3: unmet.append("liquidez < $10K")
        if h1 is None or not (0 < h1 <= 60): unmet.append("sin impulso moderado positivo en 1 h")
        if m5 is not None and m5 <= -5: unmet.append("caída reciente en 5 min")
        if ratio is not None and ratio < .5: unmet.append("más ventas que compras")
        if unmet:
            signal = "ESPERAR"; reasons.append("Faltan confirmaciones: " + "; ".join(unmet))
            change.append("Para pasar a ENTRADA POTENCIAL tendría que cumplirse: " + "; ".join(unmet) + ".")
        else:
            signal = "ENTRADA POTENCIAL"
            reasons.append("Hay señales favorables y no se detectan alertas graves; verifica el contrato por tu cuenta")
            change.append("Dejaría de ser favorable si el riesgo sube, la liquidez cae o aparece más venta que compra.")

    # ---------------- Niveles (cálculo por reglas) ----------------
    levels = None
    if price and signal in ("ENTRADA POTENCIAL", "ESPERAR"):
        refs = {w: price / (1 + pc[w] / 100) for w in ("m5", "h1", "h6", "h24") if pc.get(w) is not None and pc[w] > -99.9}
        if (m5 or 0) > 10:
            lo, hi, note = price * .88, price * .95, "El precio subió rápido en 5 min: la zona es un retroceso, no el precio actual."
        else:
            lo, hi, note = price * .95, price, "Zona de compra escalonada cerca del precio actual."
        mid = (lo + hi) / 2
        inval = lo * .92
        rr = lambda t: round((t - mid) / (mid - inval), 2)
        levels = {
            "entry_zone": [lo, hi], "invalidation": inval, "entry_note": note, "reference_prices": refs,
            "targets": [{"label": l, "price": mid * m, "gain_pct": (m - 1) * 100, "risk_reward": rr(mid * m)}
                        for l, m in (("T1", 1.3), ("T2", 1.6), ("T3", 2.0))],
            "impact_100_usd_pct": round(200 / liq * 100, 2) if liq else None,
            "impact_1000_usd_pct": round(200 / liq * 1000, 2) if liq else None,
            "note": "Niveles calculados por reglas fijas sobre el precio actual. No son predicciones ni garantía.",
        }
    exits = []
    if price:
        exits = [
            {"text": "El precio cae por debajo del nivel de invalidación (vigílalo manualmente)", "active": None},
            {"text": "La liquidez cae ≥30% en 1 hora", "active": "perdida_liquidez" in alerts},
            {"text": "Caída ≥8% en 5 min con 1 h negativa", "active": bool(m5 is not None and m5 <= -8 and h1 is not None and h1 <= 0)},
            {"text": "Más ventas que compras de forma sostenida (<40% compras)", "active": bool(ratio is not None and ntx >= 10 and ratio < .4)},
            {"text": "Aparece un riesgo confirmado (honeypot, impuesto extremo)", "active": bool(critical)},
        ]

    # ---------------- Textos explicativos ----------------
    pos = [f"{x['name']}: {x['detail']}" for x in fac if x["max"] and x["points"] >= .65 * x["max"]]
    neg = [x["text"] for x in sorted(flags, key=lambda z: -z["weight"]) if x["level"] not in (UNK, "inherente")]
    neg += [f"{x['name']}: {x['detail']}" for x in fac if x["max"] and x["points"] <= .2 * x["max"] and x["detail"] and "no disponible" not in x["detail"]]
    name = token.get("name") or token.get("symbol") or "Esta moneda"
    summary = (f"{name} tiene {fmt_age(age)} de antigüedad, liquidez {fmt_usd(liq)} y volumen 24 h {fmt_usd(vol.get('h24'))}. "
               f"Etapa: {STAGE_LABELS[stage]}. Oportunidad {opp}/100, riesgo {risk}/100 (confianza {conf_label}). "
               f"Clasificación: {CLASS_LABELS[cls]}. Señal: {signal}.")
    why = ("Detectada por " + ", ".join(token.get("sources") or ["fuente desconocida"]) +
           (f"; par creado hace {fmt_age(age)}" if age is not None else "") + ".")
    return {
        "opportunity": opp, "risk": risk, "confidence": conf, "confidence_label": conf_label,
        "classification": cls, "classification_label": CLASS_LABELS[cls], "stage": stage,
        "stage_label": STAGE_LABELS[stage], "signal": signal, "signal_reasons": reasons,
        "what_would_change": change, "opportunity_factors": fac, "risk_flags": flags,
        "positives": pos, "negatives": neg, "missing": sorted(set(missing)), "alerts": sorted(set(alerts)),
        "levels": levels, "exit_signals": exits, "summary": summary, "why_detected": why,
        "metrics": {"age_min": age, "volume_accel": accel, "buy_ratio": ratio, "liquidity_drop": drop},
        "disclaimer": DISCLAIMER,
    }
