"""Normaliza respuestas de DexScreener y GeckoTerminal a un mismo formato y las fusiona."""
import copy

from . import chains
from .util import num, iso_to_ms

WINDOWS = ("m5", "h1", "h6", "h24")


def token_key(chain, address):
    return f"{chain}:{chains.norm_addr(chain, address)}"


def _blank(chain, address, source):
    return {
        "key": token_key(chain, address), "chain": chain, "address": chains.norm_addr(chain, address),
        "name": None, "symbol": None, "pair_address": None, "dex": None, "quote_symbol": None,
        "price_usd": None, "liquidity_usd": None, "market_cap": None, "fdv": None,
        "volume": {w: None for w in WINDOWS},
        "price_change": {w: None for w in WINDOWS},
        "txns": {w: {"buys": None, "sells": None, "buyers": None, "sellers": None} for w in WINDOWS},
        "pair_created_at": None, "sources": [source],
        "info": {"website": None, "twitter": None, "telegram": None},
    }


def bare(stored):
    """Observación solo con identidad (sin métricas) de una moneda ya guardada, para refrescarla
    sin que sus métricas viejas compitan con las nuevas. Conserva sus fuentes (p. ej. FOMO)."""
    t = _blank(stored["chain"], stored["address"], "refresco")
    t["name"], t["symbol"] = stored.get("name"), stored.get("symbol")
    t["sources"] = list(stored.get("sources") or [])
    t["info"] = dict(stored.get("info") or t["info"])
    t["pair_created_at"] = stored.get("pair_created_at")
    return t


def from_dexscreener_pair(p, source="dexscreener:pares"):
    if not isinstance(p, dict):
        return None
    chain = chains.from_dexscreener(p.get("chainId"))
    base = p.get("baseToken") or {}
    addr = base.get("address")
    if not chain or not addr:
        return None
    t = _blank(chain, addr, source)
    t["name"], t["symbol"] = base.get("name"), base.get("symbol")
    t["pair_address"] = p.get("pairAddress")
    t["dex"] = p.get("dexId")
    t["quote_symbol"] = (p.get("quoteToken") or {}).get("symbol")
    t["price_usd"] = num(p.get("priceUsd"))
    t["liquidity_usd"] = num((p.get("liquidity") or {}).get("usd"))
    t["market_cap"] = num(p.get("marketCap"))
    t["fdv"] = num(p.get("fdv"))
    for w in WINDOWS:
        t["volume"][w] = num((p.get("volume") or {}).get(w))
        t["price_change"][w] = num((p.get("priceChange") or {}).get(w))
        tx = (p.get("txns") or {}).get(w) or {}
        t["txns"][w]["buys"] = num(tx.get("buys"))
        t["txns"][w]["sells"] = num(tx.get("sells"))
    t["pair_created_at"] = num(p.get("pairCreatedAt"))
    info = p.get("info") or {}
    sites = info.get("websites") or []
    if sites and isinstance(sites[0], dict):
        t["info"]["website"] = sites[0].get("url")
    for s in info.get("socials") or []:
        if isinstance(s, dict):
            if s.get("type") == "twitter":
                t["info"]["twitter"] = s.get("url")
            elif s.get("type") == "telegram":
                t["info"]["telegram"] = s.get("url")
    return t


def from_dexscreener_profile(entry, source):
    """Perfiles/boosts: solo dan (red, token); las métricas llegan al enriquecer."""
    if not isinstance(entry, dict):
        return None
    chain = chains.from_dexscreener(entry.get("chainId"))
    addr = entry.get("tokenAddress")
    if not chain or not addr:
        return None
    t = _blank(chain, addr, source)
    for link in entry.get("links") or []:
        if not isinstance(link, dict):
            continue
        typ = (link.get("type") or link.get("label") or "").lower()
        if typ == "twitter":
            t["info"]["twitter"] = link.get("url")
        elif typ == "telegram":
            t["info"]["telegram"] = link.get("url")
        elif typ in ("website", "site"):
            t["info"]["website"] = link.get("url")
    return t


def parse_gt_payload(payload, source="geckoterminal:nuevos"):
    """Convierte una respuesta de pools de GeckoTerminal (con include=base_token)."""
    out = []
    if not isinstance(payload, dict):
        return out
    included = {}
    for inc in payload.get("included") or []:
        if isinstance(inc, dict) and inc.get("id"):
            included[inc["id"]] = inc.get("attributes") or {}
    for item in payload.get("data") or []:
        t = from_gt_pool(item, included, source)
        if t:
            out.append(t)
    return out


def from_gt_pool(item, included, source):
    if not isinstance(item, dict):
        return None
    attrs = item.get("attributes") or {}
    rel = item.get("relationships") or {}
    net = ((rel.get("network") or {}).get("data") or {}).get("id")
    chain = chains.from_gt(net)
    bt_id = ((rel.get("base_token") or {}).get("data") or {}).get("id")
    tok = included.get(bt_id) or {}
    addr = tok.get("address")
    if not addr and bt_id and net and bt_id.startswith(net + "_"):
        addr = bt_id[len(net) + 1:]
    if not chain or not addr:
        return None
    t = _blank(chain, addr, source)
    pool_name = attrs.get("name") or ""
    parts = [x.strip() for x in pool_name.split(" / ")]
    t["name"] = tok.get("name") or (parts[0] if parts and parts[0] else None)
    t["symbol"] = tok.get("symbol") or (parts[0] if parts and parts[0] else None)
    t["quote_symbol"] = parts[1].split(" ")[0] if len(parts) > 1 and parts[1] else None
    t["pair_address"] = attrs.get("address")
    t["dex"] = ((rel.get("dex") or {}).get("data") or {}).get("id")
    t["price_usd"] = num(attrs.get("base_token_price_usd"))
    t["liquidity_usd"] = num(attrs.get("reserve_in_usd"))
    t["fdv"] = num(attrs.get("fdv_usd"))
    t["market_cap"] = num(attrs.get("market_cap_usd"))
    pcp, vol, txs = (attrs.get("price_change_percentage") or {}), (attrs.get("volume_usd") or {}), (attrs.get("transactions") or {})
    for w in WINDOWS:
        t["price_change"][w] = num(pcp.get(w))
        t["volume"][w] = num(vol.get(w))
        tx = txs.get(w) or {}
        for k in ("buys", "sells", "buyers", "sellers"):
            t["txns"][w][k] = num(tx.get(k))
    t["pair_created_at"] = iso_to_ms(attrs.get("pool_created_at"))
    return t


def _fill_missing(dst, src):
    for k, v in src.items():
        if isinstance(v, dict) and isinstance(dst.get(k), dict):
            _fill_missing(dst[k], v)
        elif dst.get(k) is None and v is not None:
            dst[k] = v


def merge_tokens(observations):
    """Une observaciones de la misma moneda (mismas o distintas fuentes) en un registro.

    - Par principal = el de mayor liquidez conocida.
    - Datos faltantes se completan con otra observación del MISMO par.
    - `sources` es la unión de todas las fuentes que vieron la moneda.
    - `pair_created_at` = el par más antiguo conocido (antigüedad de la moneda).
    """
    obs = [o for o in observations if o]
    if not obs:
        return None
    primary = max(obs, key=lambda o: o.get("liquidity_usd") if o.get("liquidity_usd") is not None else -1)
    out = copy.deepcopy(primary)
    sources = set(out["sources"])
    created = [o["pair_created_at"] for o in obs if o.get("pair_created_at")]
    for o in obs:
        sources |= set(o["sources"])
        if o is primary:
            continue
        same_pair = (o.get("pair_address") and out.get("pair_address")
                     and o["pair_address"].lower() == out["pair_address"].lower())
        if same_pair or not out.get("pair_address"):
            _fill_missing(out, o)
        else:
            _fill_missing({"info": out["info"], "name": None}, {"info": o["info"]})
            for k in ("website", "twitter", "telegram"):
                if out["info"].get(k) is None:
                    out["info"][k] = o["info"].get(k)
            for k in ("name", "symbol"):
                if out.get(k) is None:
                    out[k] = o.get(k)
    out["sources"] = sorted(sources)
    out["pair_created_at"] = min(created) if created else None
    return out


def blank(chain, address, source):
    """Registro vacío (sin métricas) para monedas conocidas solo por su contrato."""
    return _blank(chain, address, source)


_FOMO_NETS = {1399811149: "solana", 1: "ethereum", 8453: "base", 56: "bsc", 10: "optimism", 42161: "arbitrum",
              137: "polygon", 43114: "avalanche",
              "sol": "solana", "solana": "solana", "eth": "ethereum", "ethereum": "ethereum", "base": "base",
              "bsc": "bsc", "bnb": "bsc", "bnb chain": "bsc", "bnbchain": "bsc"}


def from_fomo_entry(entry, board):
    """Entrada de un tablero de fomoapi.io. Solo trae precio/cap/cambio 24 h; el resto llega al enriquecer
    con DexScreener. Si la red no está en el mapa se conserva tal cual (no se descarta la moneda)."""
    if not isinstance(entry, dict):
        return None
    tok = entry.get("token") or {}
    addr = tok.get("address")
    net = entry.get("network")
    if not addr or net is None:
        return None
    key = net.lower() if isinstance(net, str) else net
    chain = _FOMO_NETS.get(key, str(net).lower())
    t = _blank(chain, addr, f"fomo:{board}")
    t["name"], t["symbol"] = tok.get("name"), tok.get("symbol")
    t["price_usd"] = num(entry.get("priceUsd"))
    t["market_cap"] = num(entry.get("marketCapUsd"))
    t["price_change"]["h24"] = num(entry.get("change24h"))
    return t
