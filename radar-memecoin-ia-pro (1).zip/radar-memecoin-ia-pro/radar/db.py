"""Persistencia SQLite (biblioteca estándar). Un solo acceso a la vez mediante RLock."""
import json
import sqlite3
import threading
from pathlib import Path

from .alerts import DEFAULT_SETTINGS

SCHEMA = """
CREATE TABLE IF NOT EXISTS tokens(
  key TEXT PRIMARY KEY, chain TEXT, address TEXT, name TEXT, symbol TEXT,
  first_seen INTEGER, last_seen INTEGER, updated INTEGER,
  token_json TEXT, analysis_json TEXT, opp REAL, risk REAL, classification TEXT, stage TEXT, signal TEXT,
  base_opp REAL, base_risk REAL);
CREATE TABLE IF NOT EXISTS security(key TEXT PRIMARY KEY, ts INTEGER, json TEXT);
CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT, ts INTEGER,
  price REAL, liq REAL, vol24 REAL, vol1h REAL, mcap REAL, buys1h REAL, sells1h REAL);
CREATE INDEX IF NOT EXISTS ix_snap ON snapshots(key, ts);
CREATE TABLE IF NOT EXISTS score_history(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT, ts INTEGER,
  opp REAL, risk REAL, classification TEXT, signal TEXT);
CREATE INDEX IF NOT EXISTS ix_score ON score_history(key, ts);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT, ts INTEGER, kind TEXT,
  severity TEXT, title TEXT, message TEXT, telegram TEXT);
CREATE INDEX IF NOT EXISTS ix_alert ON alerts(key, kind, ts);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
"""
SNAPSHOT_GAP_MS = 180_000


class Database:
    def __init__(self, path):
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self._last_snap = {}
        with self.lock:
            if path != ":memory:":
                self.conn.execute("PRAGMA journal_mode=WAL")
            self.conn.executescript(SCHEMA)
            self.conn.commit()

    def _x(self, sql, args=()):
        with self.lock:
            cur = self.conn.execute(sql, args)
            self.conn.commit()
            return cur

    def _q(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    # ---- tokens ----
    @staticmethod
    def _row(r):
        if r is None:
            return None
        r = dict(r)
        r["token"] = json.loads(r.pop("token_json") or "{}")
        r["analysis"] = json.loads(r.pop("analysis_json") or "{}")
        return r

    def get_token(self, key):
        rows = self._q("SELECT * FROM tokens WHERE key=?", (key,))
        return self._row(rows[0]) if rows else None

    def list_tokens(self):
        return [self._row(r) for r in self._q("SELECT * FROM tokens")]

    def count_tokens(self):
        return self._q("SELECT COUNT(*) c FROM tokens")[0]["c"]

    def save_token(self, token, analysis, ts, base_opp=None, base_risk=None):
        prev = self.get_token(token["key"])
        first = prev["first_seen"] if prev else ts
        bo = base_opp if base_opp is not None else (prev["base_opp"] if prev and prev["base_opp"] is not None else analysis["opportunity"])
        br = base_risk if base_risk is not None else (prev["base_risk"] if prev and prev["base_risk"] is not None else analysis["risk"])
        self._x("""INSERT INTO tokens(key,chain,address,name,symbol,first_seen,last_seen,updated,token_json,analysis_json,
                   opp,risk,classification,stage,signal,base_opp,base_risk) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(key) DO UPDATE SET name=excluded.name,symbol=excluded.symbol,last_seen=excluded.last_seen,
                   updated=excluded.updated,token_json=excluded.token_json,analysis_json=excluded.analysis_json,
                   opp=excluded.opp,risk=excluded.risk,classification=excluded.classification,stage=excluded.stage,
                   signal=excluded.signal,base_opp=excluded.base_opp,base_risk=excluded.base_risk""",
                (token["key"], token["chain"], token["address"], token.get("name"), token.get("symbol"), first, ts, ts,
                 json.dumps(token), json.dumps(analysis), analysis["opportunity"], analysis["risk"],
                 analysis["classification"], analysis["stage"], analysis["signal"], bo, br))

    def touch(self, key, ts):
        self._x("UPDATE tokens SET last_seen=? WHERE key=?", (ts, key))

    def set_base(self, key, opp, risk):
        self._x("UPDATE tokens SET base_opp=?, base_risk=? WHERE key=?", (opp, risk, key))

    # ---- seguridad ----
    def get_security(self, key):
        r = self._q("SELECT ts,json FROM security WHERE key=?", (key,))
        return (r[0]["ts"], json.loads(r[0]["json"])) if r else (None, None)

    def put_security(self, key, sec, ts):
        self._x("INSERT INTO security(key,ts,json) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET ts=?,json=?",
                (key, ts, json.dumps(sec), ts, json.dumps(sec)))

    # ---- historial ----
    def add_snapshot(self, key, ts, t):
        if ts - self._last_snap.get(key, 0) < SNAPSHOT_GAP_MS:
            return False
        self._last_snap[key] = ts
        tx = (t.get("txns") or {}).get("h1") or {}
        self._x("INSERT INTO snapshots(key,ts,price,liq,vol24,vol1h,mcap,buys1h,sells1h) VALUES(?,?,?,?,?,?,?,?,?)",
                (key, ts, t.get("price_usd"), t.get("liquidity_usd"), (t.get("volume") or {}).get("h24"),
                 (t.get("volume") or {}).get("h1"), t.get("market_cap") or t.get("fdv"), tx.get("buys"), tx.get("sells")))
        return True

    def history(self, key, since_ts=0, limit=500):
        return self._q("SELECT ts,price,liq,vol24,vol1h,mcap,buys1h,sells1h FROM snapshots WHERE key=? AND ts>=? "
                       "ORDER BY ts DESC LIMIT ?", (key, since_ts, limit))[::-1]

    def add_score_point(self, key, ts, a):
        last = self._q("SELECT opp,risk,classification,signal FROM score_history WHERE key=? ORDER BY ts DESC LIMIT 1", (key,))
        if last:
            l = last[0]
            if (abs(l["opp"] - a["opportunity"]) < 1 and abs(l["risk"] - a["risk"]) < 1
                    and l["classification"] == a["classification"] and l["signal"] == a["signal"]):
                return False
        self._x("INSERT INTO score_history(key,ts,opp,risk,classification,signal) VALUES(?,?,?,?,?,?)",
                (key, ts, a["opportunity"], a["risk"], a["classification"], a["signal"]))
        return True

    def score_history(self, key, limit=100):
        return self._q("SELECT ts,opp,risk,classification,signal FROM score_history WHERE key=? ORDER BY ts DESC LIMIT ?",
                       (key, limit))[::-1]

    # ---- alertas ----
    def add_alert(self, key, kind, severity, title, message, ts, cooldown_ms):
        """Inserta salvo que exista la misma (moneda, tipo) dentro del enfriamiento -> evita duplicados."""
        dup = self._q("SELECT id FROM alerts WHERE key=? AND kind=? AND ts>? LIMIT 1", (key, kind, ts - cooldown_ms))
        if dup:
            return None
        cur = self._x("INSERT INTO alerts(key,ts,kind,severity,title,message,telegram) VALUES(?,?,?,?,?,?,?)",
                      (key, ts, kind, severity, title, message, "pendiente"))
        return cur.lastrowid

    def set_alert_telegram(self, alert_id, status):
        self._x("UPDATE alerts SET telegram=? WHERE id=?", (status, alert_id))

    def recent_alerts(self, limit=100, key=None):
        if key:
            return self._q("SELECT * FROM alerts WHERE key=? ORDER BY ts DESC LIMIT ?", (key, limit))
        return self._q("SELECT a.*, t.name, t.symbol, t.chain FROM alerts a LEFT JOIN tokens t ON t.key=a.key "
                       "ORDER BY a.ts DESC LIMIT ?", (limit,))

    # ---- ajustes ----
    def get_settings(self):
        out = json.loads(json.dumps(DEFAULT_SETTINGS))
        r = self._q("SELECT v FROM settings WHERE k='main'")
        if r:
            saved = json.loads(r[0]["v"])
            out["telegram_enabled"] = bool(saved.get("telegram_enabled", out["telegram_enabled"]))
            out["alerts"].update({k: bool(v) for k, v in (saved.get("alerts") or {}).items() if k in out["alerts"]})
            for k, v in (saved.get("thresholds") or {}).items():
                if k in out["thresholds"] and isinstance(v, (int, float)) and not isinstance(v, bool):
                    out["thresholds"][k] = v
        return out

    def set_settings(self, new):
        cur = self.get_settings()
        if "telegram_enabled" in new:
            cur["telegram_enabled"] = bool(new["telegram_enabled"])
        for k, v in (new.get("alerts") or {}).items():
            if k in cur["alerts"]:
                cur["alerts"][k] = bool(v)
        for k, v in (new.get("thresholds") or {}).items():
            if k in cur["thresholds"] and isinstance(v, (int, float)) and not isinstance(v, bool) and v == v:
                cur["thresholds"][k] = v
        self._x("INSERT INTO settings(k,v) VALUES('main',?) ON CONFLICT(k) DO UPDATE SET v=?",
                (json.dumps(cur), json.dumps(cur)))
        return cur

    def prune(self, now, keep_days=3):
        cutoff = now - keep_days * 86400_000
        self._x("DELETE FROM snapshots WHERE ts<?", (cutoff,))
