#!/usr/bin/env python3
"""Radar Memecoin IA PRO: arranque. Sin dependencias externas (solo Python 3.9+).

  python3 run.py            # servidor + monitoreo continuo
  python3 run.py --once     # un ciclo de recolección y resumen en consola
"""
import argparse
import sys

from radar.collector import Collector
from radar.config import Config, load_env
from radar.db import Database
from radar.http import Fetcher, SourceStatus
from radar.server import App, make_server
from radar.telegram import Telegram


def build():
    load_env()
    cfg = Config()
    fetcher = Fetcher(SourceStatus(), secrets=cfg.secrets())
    db = Database(cfg.db_path)
    tg = Telegram(cfg, fetcher)
    return cfg, db, fetcher, tg, Collector(cfg, db, fetcher, tg)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--host")
    ap.add_argument("--port", type=int)
    args = ap.parse_args()
    cfg, db, fetcher, tg, collector = build()
    if args.once:
        st = collector.run_cycle()
        print(f"Monedas vistas: {st['tokens_seen']} · nuevas: {st['new_tokens']} · alertas: {st['alerts_created']} · {st['last_seconds']}s")
        for s in fetcher.status.snapshot():
            print(f"  {s['label']:<38} {s['state']:<8} errores={s['errors']} {s['last_error'] or ''}")
        for e in st["errors"]:
            print("  ! " + e)
        return 0
    host, port = args.host or cfg.host, args.port or cfg.port
    if host not in ("127.0.0.1", "localhost", "::1") and not cfg.admin_token:
        print("AVISO: expones el panel fuera de tu equipo sin RADAR_ADMIN_TOKEN; los ajustes seguirán restringidos al equipo local.")
    collector.start()
    srv = make_server(App(cfg, db, collector, fetcher, tg), host, port)
    print(f"Radar Memecoin IA PRO en http://{host}:{port}  (Ctrl+C para salir)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        collector.stop()
        srv.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
